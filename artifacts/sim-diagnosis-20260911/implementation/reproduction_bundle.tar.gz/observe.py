import json, math, time, signal, gzip
from collections import deque, Counter
from pathlib import Path as File
import rclpy, hdmap
from rclpy.qos import QoSProfile, ReliabilityPolicy
from interfaces.msg import EgoStatus, ControlCommand, TrafficLight, DynamicStatus
from rclpy.serialization import serialize_message
from nav_msgs.msg import Path
from std_msgs.msg import Float32, Int64MultiArray, String
from rcl_interfaces.msg import Log
from lanelet2.core import BasicPoint2d

out=File('/tmp/sim_fix_20260911')
f=(out/'events.jsonl').open('a',buffering=1)
model=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin')
cells=model.cells(); lanes=model.laneletMap().laneletLayer
start=time.monotonic(); counts=Counter(); history=deque(maxlen=250); last={}; stop=False
egomsgs=deque(maxlen=150); dynamics=deque(maxlen=15); saved=set(); last_capture=0.0
metadata=(out/'snapshots.jsonl').open('a',buffering=1)

def ns(st):return st.sec*1_000_000_000+st.nanosec

def write(topic,data,stamp=None):
    counts[topic]+=1
    row={'t':time.time(),'topic':topic,'data':data}
    if stamp is not None:row['stamp']=stamp
    f.write(json.dumps(row,separators=(',',':'))+'\n')

def ego(m):
    d={k:float(getattr(m,k)) for k in ('x','y','z','heading','speed')}
    history.append((ns(m.header.stamp),d));egomsgs.append(m);last['ego']=d
    write('ego',d,ns(m.header.stamp))

def path(m):
    pts=[[p.pose.position.x,p.pose.position.y,p.pose.orientation.z,p.pose.orientation.w] for p in m.poses]
    stamp=ns(m.header.stamp)
    d={'frame':m.header.frame_id,'points':pts}
    if history:
        st,e=min(history,key=lambda a:abs(a[0]-stamp))
        d['capture']=e;d['capture_error_ms']=(st-stamp)/1e6
        if pts:
            c,s=math.cos(e['heading']),math.sin(e['heading']);x,y=pts[-1][:2]
            last['end']=[e['x']+c*x-s*y,e['y']+s*x+c*y]
    last['path_t']=time.monotonic();last['path_n']=len(pts)
    write('path',d,stamp)
    length=sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(pts,pts[1:]))
    if length<15 and time.monotonic()-last_capture>2.:
        for dyn in reversed(dynamics):
            if ns(dyn.header.stamp)==stamp:capture(dyn,'short_path');break

def status(m):
    state=m.data.split()[0];old=last.get('state');last['state']=state
    write('status',m.data)
    if state!=old:print('STATE',round(time.monotonic()-start,2),m.data,flush=True)

def command(m):
    d={'steering':m.steering,'accel':m.target_accel};last['cmd']=d
    write('command',d,ns(m.header.stamp))

def cap(m):
    last['cap']=m.data;write('cap',m.data)

def route(m):
    d=list(m.data)
    if d!=last.get('route'):print('ROUTE',round(time.monotonic()-start,2),d[:12],'n',len(d),flush=True)
    last['route']=d;write('route',d)

def light(m):
    d=[m.id,m.state];last['light']=d;write('light',d,ns(m.header.stamp))

def log(m):
    if m.name in ('mpc_control','path_planner','hdmap_dynamic_tracker','sim_bridge'):
        write('log',{'name':m.name,'level':m.level,'text':m.msg},ns(m.stamp))

def summary():
    if 'ego' not in last:return
    e=last['ego'];c,s=math.cos(e['heading']),math.sin(e['heading'])
    box=[BasicPoint2d(e['x']+c*x-s*y,e['y']+s*x+c*y) for x,y in ((3.808,.943),(3.808,-.943),(-1.04,-.943),(-1.04,.943))]
    ids=model.cellTree().queryOverlaps(box,e['z'],e['z']+1.507)
    data={'ego':e,'cap':last.get('cap'),'state':last.get('state'),'cmd':last.get('cmd'),'route':last.get('route',[])[:5],'light':last.get('light'),'path_n':last.get('path_n'),'path_age':time.monotonic()-last.get('path_t',start),'end':last.get('end'),'cells':[[cid,cells[cid].parent().lanelet_id,dict(cells[cid].polygon3d().attributes).get('speed_limit')] for cid in ids]}
    write('summary',data)
    if int(time.monotonic()-start)%5==0:print('SAMPLE',round(time.monotonic()-start,1),json.dumps(data),flush=True)


def capture(m,reason):
    global last_capture
    stamp=ns(m.header.stamp)
    if stamp in saved:return
    e=next((e for e in reversed(egomsgs) if ns(e.header.stamp)==stamp),None)
    if e is None:return
    stem=out/'snapshots'/str(stamp)
    with gzip.open(str(stem)+'.dynamic.cdr.gz','wb',compresslevel=1) as f:f.write(serialize_message(m))
    File(str(stem)+'.ego.cdr').write_bytes(serialize_message(e))
    meta={'t':time.time(),'stamp':stamp,'reason':reason,'route':last.get('route',[]),'status':last.get('state'),'ego':{k:float(getattr(e,k)) for k in ('x','y','z','heading','pitch','roll','speed')},'dynamic_bytes':len(m.occupancy_probability)*4+len(m.speed_cap_mps)*4}
    File(str(stem)+'.json').write_text(json.dumps(meta))
    metadata.write(json.dumps(meta)+'\n');saved.add(stamp);last_capture=time.monotonic()

def dynamic(m):
    dynamics.append(m)
    counts['dynamic']+=1
    if time.monotonic()-last_capture>(3. if last.get('ego',{}).get('speed',0)>.1 else 10.):capture(m,'periodic')

rclpy.init();node=rclpy.create_node('sim_fix_verification_observer')
q=QoSProfile(depth=10,reliability=ReliabilityPolicy.BEST_EFFORT)
for typ,name,fn in ((EgoStatus,'/ego_status',ego),(Path,'/local_path',path),(String,'/control/status',status),(ControlCommand,'/ctrl_cmd',command),(Float32,'/speed_limit',cap),(Int64MultiArray,'/global_path',route),(TrafficLight,'/traffic_light',light),(Log,'/rosout',log)):
    node.create_subscription(typ,name,fn,q)
node.create_subscription(DynamicStatus,'/dynamic_status',dynamic,QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT))
node.create_timer(.5,summary)
print('READY',time.time(),flush=True)
try:
    while rclpy.ok() and time.monotonic()-start<3600:rclpy.spin_once(node,timeout_sec=.2)
except KeyboardInterrupt:pass
finally:
    print('COUNTS',dict(counts),flush=True);f.close();node.destroy_node()
    if rclpy.ok():rclpy.shutdown()
