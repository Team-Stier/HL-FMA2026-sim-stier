import json,math,bisect
from pathlib import Path
import numpy as np
out=Path('/tmp/sim_fix_20260911/control_recovery_analysis')
rows=[]
for l in open('/tmp/sim_fix_20260911/events.jsonl'):
 a=json.loads(l)
 if 1789080703<a['t']<1789080717:rows.append(a)
e=[a for a in rows if a['topic']=='ego'];c=[a for a in rows if a['topic']=='command'];statuses=[a for a in rows if a['topic']=='status']
peak=max(range(len(e)),key=lambda i:e[i]['data']['speed']);report=[]
for i in range(peak-4,peak+5):
 a=e[i];prev=e[i-1];dt=(a['stamp']-prev['stamp'])/1e9;distance=math.hypot(a['data']['x']-prev['data']['x'],a['data']['y']-prev['data']['y']);r={'t':a['t'],'stamp':a['stamp']/1e9,**a['data'],'dt':dt,'distance':distance,'xy_speed':distance/dt};report.append(r)
et=np.array([a['stamp']/1e9 for a in e]);ep=np.array([[a['data'][k] for k in ('x','y','heading','speed')] for a in e]);ep[:,2]=np.unwrap(ep[:,2]);ct=np.array([a['stamp']/1e9 for a in c]);cd=np.array([a['data']['steering'] for a in c])
ts=np.arange(1789080707.5,1789080713.2,.025);hw=.1
def interp(k,t=ts):return np.interp(t,et,ep[:,k])
omega=(interp(2,ts+hw)-interp(2,ts-hw))/(2*hw);vx=(interp(0,ts+hw)-interp(0,ts-hw))/(2*hw);vy=(interp(1,ts+hw)-interp(1,ts-hw))/(2*hw);v=np.hypot(vx,vy);h=interp(2)
fits=[]
for lag in np.arange(0,.151,.01):
 window=ts[:,None]+np.linspace(-hw,hw,21)[None,:];idx=np.clip(np.searchsorted(ct,window-lag,side='right')-1,0,len(cd)-1);pred=np.mean(np.interp(window,et,ep[:,3])*np.tan(cd[idx])/2.944,axis=1);mask=(v>2)&(abs(pred)>.02)
 gain=float(pred[mask]@omega[mask]/(pred[mask]@pred[mask]));err=omega[mask]-gain*pred[mask];fits.append({'lag':float(lag),'gain':gain,'rmse':float(np.sqrt(np.mean(err**2)))})
best=min(fits,key=lambda a:a['rmse']);window=ts[:,None]+np.linspace(-hw,hw,21)[None,:];idx=np.clip(np.searchsorted(ct,window-best['lag'],side='right')-1,0,len(cd)-1);pred=np.mean(np.interp(window,et,ep[:,3])*np.tan(cd[idx])/2.944,axis=1)
bins=[]
for lo,hi in [(2,4),(4,6),(6,7),(7,8),(8,10)]:
 mask=(v>=lo)&(v<hi)&(abs(pred)>.02)
 if not mask.any():continue
 bins.append({'xy_speed_range':[lo,hi],'samples':int(mask.sum()),'gain':float(pred[mask]@omega[mask]/(pred[mask]@pred[mask]))})
rawspeedpeak=e[peak];peakstamp=rawspeedpeak['stamp']/1e9;speed200=math.hypot(float(interp(0,np.array([peakstamp+hw]))[0]-interp(0,np.array([peakstamp-hw]))[0]),float(interp(1,np.array([peakstamp+hw]))[0]-interp(1,np.array([peakstamp-hw]))[0]))/(2*hw)
nearcommands=[]
for a in c:
 if abs(a['t']-rawspeedpeak['t'])<.25 or abs(a['t']-1789080713.374)<.12:
  nearest=min(statuses,key=lambda s:abs(s['t']-a['t']));nearcommands.append({'t':a['t'],'cmd':a['data'],'paired_status_t':nearest['t'],'paired_status':nearest['data']})
result={'speed_peak_samples':report,'peak_xy_speed_200ms':speed200,'latest_yaw_response_best':best,'speed_bins':bins,'commands_near_peak_or_failure':nearcommands}
(out/'physical_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
old=[json.loads(l) for l in Path('/tmp/sim_fix_20260911/control_analysis/geometry_combined.jsonl').open()];new=[json.loads(l) for l in (out/'geometry_combined.jsonl').open()]
aligned=[]
for x in [800,805,810,815,820,825,829,830]:
 a=min(old,key=lambda a:abs(a['ego']['x']-x));b=min(new,key=lambda a:abs(a['ego']['x']-x));r={'x_target':x,'old_t':a['t'],'new_t':b['t'],'old_road_d':a['centerline']['signed'],'new_road_d':b['centerline']['signed'],'old_ey':a['analysis']['ey'],'new_ey':b['ey'],'old_v':a['ego']['speed'],'new_v':b['ego']['speed']};aligned.append(r)
(out/'position_comparison.json').write_text(json.dumps(aligned,indent=2)+'\n');print('position comparison',json.dumps(aligned,indent=2))
