import json,math
from pathlib import Path
out=Path('/tmp/sim_fix_20260911/control_recovery_analysis')
latest={};meta=[];lines=[];prev=0.;allcmd=[];paths=[]
for line in open('/tmp/sim_fix_20260911/events.jsonl'):
 a=json.loads(line);t=a['t']
 if t<1789080699:continue
 if t>1789080718:break
 topic=a['topic'];latest[topic]=a
 if topic=='path':paths.append(a)
 if topic!='command':continue
 e=latest.get('ego',{});p=latest.get('path',{});status=latest.get('status',{}).get('data','')
 item={'t':t,'ego':e.get('data'),'ego_stamp':e.get('stamp'),'ego_receive_t':e.get('t'),'status':status,'cmd':a['data'],'command_stamp':a.get('stamp'),'prevsteer':prev,'cap':latest.get('cap',{}).get('data'),'route':latest.get('route',{}).get('data')}
 prev=a['data']['steering'];allcmd.append(item)
 if not (status.startswith('state=ACTIVE') and p and p['data']['points']):continue
 c=p['data']['capture'];points=p['data']['points'];speed=e['data']['speed'];eg=e['data']
 item.update(capture=c,path_stamp=p['stamp']/1e9,path_t=p['t'],path_age_s=(a['stamp']-p['stamp'])/1e9,capture_error_ms=p['data'].get('capture_error_ms'),path_n=len(points),ego_age_s=(a['stamp']-e['stamp'])/1e9,path_compute_receive_s=p['t']-p['stamp']/1e9)
 meta.append(item)
 vals=[len(meta)-1,t,speed,eg['x'],eg['y'],eg['heading'],c['x'],c['y'],c['heading'],p['stamp']/1e9,item['prevsteer'],len(points)]
 for pt in points:vals+=pt[:2]
 lines.append(' '.join(str(v) for v in vals))
(out/'replay_meta.json').write_text(json.dumps(meta))
(out/'all_commands.jsonl').write_text('\n'.join(json.dumps(a) for a in allcmd)+'\n')
(out/'paths.jsonl').write_text('\n'.join(json.dumps(a) for a in paths)+'\n')
(out/'replay_input.txt').write_text('\n'.join(lines)+'\n')
s=Path('/tmp/sim_fix_20260911/control_analysis/replay.cpp').read_text().replace('/control_analysis/replay_input.txt','/control_recovery_analysis/replay_input.txt')
(out/'replay.cpp').write_text(s)
print({'active_commands':len(meta),'first_active':meta[0]['t'],'last_active':meta[-1]['t'],'first_empty_after_active':next(a['t'] for a in paths if a['t']>meta[0]['t'] and not a['data']['points'])})
