import json,math,statistics
from pathlib import Path
import hdmap
out=Path('/tmp/sim_fix_20260911/control_recovery_analysis')
meta=json.loads((out/'replay_meta.json').read_text());replay=[json.loads(l) for l in (out/'replay_output.jsonl').open()]
assert len(meta)==len(replay)
model=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin');m=model.laneletMap();reference=[(p.x,p.y) for ident in [28004,28075,28078,29001] for p in m.laneletLayer[ident].centerline]
s=Path('/tmp/sim_fix_20260911/control_analysis/geometry.py').read_text();definition=s[s.index('def projection'):s.index('paths=[]')];exec(definition)
paths=[json.loads(l) for l in (out/'paths.jsonl').open() if json.loads(l)['data']['points']]
for a in paths:
 c=a['data']['capture'];cs,ss=math.cos(c['heading']),math.sin(c['heading']);a['world']=[(c['x']+cs*p[0]-ss*p[1],c['y']+ss*p[0]+cs*p[1]) for p in a['data']['points']]
fixed=[min(paths,key=lambda a:abs(a['t']-t)) for t in [1789080704.8,1789080708,1789080710,1789080713.3]]
rows=[]
for r,rr in zip(meta,replay):
 r.update(rr);e=r['ego'];r['centerline']=projection(e['x'],e['y'],e['heading'],reference);r['fixed_paths']=[{'path_t':p['t'],'projection':projection(e['x'],e['y'],e['heading'],p['world'])} for p in fixed];rows.append(r)
(out/'geometry_combined.jsonl').write_text('\n'.join(json.dumps(x) for x in rows)+'\n')
def stats(v):
 v=sorted(v);return {'min':v[0],'median':statistics.median(v),'p95':v[int((len(v)-1)*.95)],'max':v[-1]}
summary={'rows':len(rows),'valid':sum(r['valid'] for r in rows),'mpc_success':sum(r['success'] for r in rows),'abs_latest_path_lateral_error_m':stats([abs(r['ey']) for r in rows]),'abs_latest_path_heading_error_deg':stats([abs(math.degrees(r['epsi'])) for r in rows]),'path_age_s':stats([r['path_age_s'] for r in rows]),'ego_age_s':stats([r['ego_age_s'] for r in rows]),'path_compute_receive_s':stats([r['path_compute_receive_s'] for r in rows]),'speed_mps':stats([r['ego']['speed'] for r in rows]),'solver_steering_diff_rad':stats([abs(r['cmd']['steering']-r['solver_steer']) for r in rows])}
print(json.dumps(summary,indent=2));(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for t in range(1789080705,1789080714):
 r=min(rows,key=lambda a:abs(a['t']-t));print(round(r['t'],3),'v',round(r['ego']['speed'],4),'cmd',round(r['cmd']['steering'],5),'centerline',r['centerline'],'latest_ey',r['ey'],'latest_epsi',math.degrees(r['epsi']),'pathage',r['path_age_s'])
print('last',json.dumps({k:v for k,v in rows[-1].items() if k not in ('kappa','fixed_paths')}))
