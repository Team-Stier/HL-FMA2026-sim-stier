from pathlib import Path
import json,math,statistics,hashlib,difflib
p=Path('/tmp/control_planner_pruning_check')
rows={name:[json.loads(line) for line in (p/name/'results.jsonl').read_text().splitlines() if line.startswith('{')] for name in ('pruned','exhaustive')}
labels=[line.split()[0] for line in Path('/tmp/sim_fix_20260911/replay_inputs.txt').read_text().splitlines()]
assert len(labels)==31
assert all([r['stamp'] for r in rs]==labels for rs in rows.values()), {n:len(rs) for n,rs in rows.items()}
a=(p/'pruned/planner_current.cpp').read_text();b=(p/'exhaustive/planner_current.cpp').read_text()
assert b==a.replace('if(bound>best_cost) break;','/* exhaustive verification: skip no candidate */')
assert (p/'pruned/replay.cpp').read_bytes()==(p/'exhaustive/replay.cpp').read_bytes()
assert (p/'pruned/replay_config.inc').read_bytes()==(p/'exhaustive/replay_config.inc').read_bytes()
(p/'variant.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='pruned',tofile='exhaustive')))
checks=[]
for x,y in zip(rows['pruned'],rows['exhaustive']):
 keys=[k for k in x if k not in ('valid_candidates','elapsed_ms')]
 differs=[k for k in keys if x[k]!=y[k]]
 checks.append({'stamp':x['stamp'],'exact_equal':not differs,'different_fields':differs,'points':x['points'],'length_m':x['length'],'max_xy_distance_m':max((math.dist(i,j) for i,j in zip(x['xy'],y['xy'])),default=0),'length_difference_m':abs(x['length']-y['length']),'pruned_valid_candidates':x['valid_candidates'],'exhaustive_valid_candidates':y['valid_candidates'],'pruned_elapsed_ms':x['elapsed_ms'],'exhaustive_elapsed_ms':y['elapsed_ms']})
manifest=json.loads((p/'manifest.json').read_text())
unchanged={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in manifest['files'].items()}
summary={'source_sha256':manifest['source_sha256'],'input_count':len(checks),'exactly_equal_output_cases':sum(c['exact_equal'] for c in checks),'empty_path_cases':sum(c['points']==0 for c in checks),'total_pose_samples':sum(c['points'] for c in checks),'max_xy_distance_m':max(c['max_xy_distance_m'] for c in checks),'max_length_difference_m':max(c['length_difference_m'] for c in checks),'mismatches':[c for c in checks if not c['exact_equal']],'pruned_valid_candidates':sum(c['pruned_valid_candidates'] for c in checks),'exhaustive_valid_candidates':sum(c['exhaustive_valid_candidates'] for c in checks),'all_source_config_and_input_hashes_unchanged':all(unchanged.values()),'changed_paths':[k for k,v in unchanged.items() if not v],'timing_single_pass_not_benchmark':{name:{'median_ms':statistics.median(r['elapsed_ms'] for r in rs),'max_ms':max(r['elapsed_ms'] for r in rs),'total_ms':sum(r['elapsed_ms'] for r in rs)} for name,rs in rows.items()},'notes':['Identical frozen final version 8 in both variants; only pruning break is disabled in exhaustive.','All output positions XYZ and quaternion XYZW were emitted with 17 decimal significant digits and compared exactly.','Candidate count and wall-clock runtime intentionally excluded from output equality.','31 saved inputs only; no terminal checkpoint location and no lane-change intent were present in original replay harness.','No repository source or live simulator commands were changed by this validation; ROS domains 211 and 212.']}
(p/'per_case.json').write_text(json.dumps(checks,indent=2)+'\n');(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
assert not summary['mismatches']
