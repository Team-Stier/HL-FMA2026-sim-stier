from pathlib import Path
import shlex,subprocess,re,yaml,math,json,sys
out=Path('/tmp/control_planner_pruning_check');root=Path('/home/stier/HL-FMA2026-sim-stier')
s=(out/'planner_frozen.cpp').read_text()
config=yaml.safe_load((out/'planner_frozen.yaml').read_text())['path_planner']['ros__parameters']
fields=re.findall(r'double\s+(\w+)\s*;',s[s.index('struct PlannerConfig'):s.index('static lanelet::BasicPolygon2d footprint')])
lines=[]
for field in fields:
 key={'heading_tolerance_rad':'heading_tolerance_deg','maximum_steering_rad':'maximum_steering_deg'}.get(field,field)
 value=config[key]*(math.pi/180 if key.endswith('_deg') else 1)
 lines.append(f'cfg.{field}={value!r};')
lines.append('cfg.frenet_horizon_candidates_s={'+','.join(map(str,config['frenet_horizon_candidates_s']))+'};')
flags={line.split(' = ')[0]:shlex.split(line.split(' = ',1)[1]) for line in (root/'build/path_planner/CMakeFiles/cost_check.dir/flags.make').read_text().splitlines() if ' = ' in line}
link=shlex.split((root/'build/path_planner/CMakeFiles/cost_check.dir/link.txt').read_text())
harness=(out/'replay_original.cpp').read_text().replace('std::setprecision(12)','std::setprecision(17)')
old='  std::cout<<"]}\\n"<<std::flush;'
new='''  std::cout<<"],\\"poses\\":[";
  for(std::size_t i=0;i<replay_path.poses.size();++i) {if(i)std::cout<<",";const auto& p=replay_path.poses[i].pose;
    std::cout<<"["<<p.position.x<<","<<p.position.y<<","<<p.position.z<<","<<p.orientation.x<<","<<p.orientation.y<<","<<p.orientation.z<<","<<p.orientation.w<<"]";}
  std::cout<<"]}\\n"<<std::flush;'''
assert harness.count(old)==1
harness=harness.replace(old,new)
for variant in ('pruned','exhaustive'):
 p=out/variant;p.mkdir(exist_ok=True)
 v=s if variant=='pruned' else s.replace('if(bound>best_cost) break;','/* exhaustive verification: skip no candidate */')
 v=v.replace('        return path;','        replay_path=path; return path;').replace('        return tree;','        replay_tree=tree; return tree;')
 v='#include <nav_msgs/msg/path.hpp>\n#include "interfaces/msg/search_tree.hpp"\nnav_msgs::msg::Path replay_path;\ninterfaces::msg::SearchTree replay_tree;\n'+v
 (p/'planner_current.cpp').write_text(v);(p/'replay_config.inc').write_text('\n'.join(lines)+'\n');(p/'replay.cpp').write_text(harness)
 cmd=['/usr/bin/c++','-O2','-std=c++17',*flags['CXX_DEFINES'],*flags['CXX_INCLUDES'],str(p/'replay.cpp'),'-o',str(p/'replay'),*link[link.index('-o')+2:]]
 (p/'compile_command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 if len(sys.argv)>1 and variant!=sys.argv[1]:continue
 with (p/'compile.log').open('w') as log:
  r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print(variant,'compile exit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
