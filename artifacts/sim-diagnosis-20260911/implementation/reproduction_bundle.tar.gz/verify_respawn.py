import json,math
from pathlib import Path
p=Path('/tmp/sim_fix_20260911'); t=1789081264.4881997
rows=[]
for line in (p/'events.jsonl').open():
 r=json.loads(line)
 if t-.15<=r['t']<=t+2:rows.append(r)
ego=next(r for r in rows if r['topic']=='ego' and math.hypot(r['data']['x']-34.9641914367676,r['data']['y']-45.885799407959)<.1)
after=[r for r in rows if r['t']>=ego['t']]
route=next((r for r in after if r['topic']=='route' and r['data'] and r['data'][0]==2534),None)
path=next((r for r in after if r['topic']=='path' and r['data']['points'] and r['stamp']>=ego['stamp']),None)
empty=next((r for r in after if r['topic']=='route' and not r['data']),None)
logs=[r for r in after if r['topic']=='log' and ('reset' in r['data']['text'].lower() or 'respawn' in r['data']['text'].lower())]
result=dict(scp_t=t,first_new_ego=ego,clear_delay_ms=(empty['t']-ego['t'])*1000 if empty else None,new_global_delay_ms=(route['t']-ego['t'])*1000 if route else None,new_global=route,new_local_delay_ms=(path['t']-ego['t'])*1000 if path else None,new_local_stamp=path.get('stamp') if path else None,new_local_points=len(path['data']['points']) if path else None,max_speed_first_two_seconds=max(r['data']['speed'] for r in after if r['topic']=='ego'),logs=logs)
(p/'respawn_reachable_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
