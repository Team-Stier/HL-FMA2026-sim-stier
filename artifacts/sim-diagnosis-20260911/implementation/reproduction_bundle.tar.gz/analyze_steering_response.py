import json,numpy as np
from pathlib import Path
P=Path('/tmp/sim_fix_20260911')
data=[json.loads(l) for l in open(P/'events.jsonl')]
cases=[('north',1789079834.,1789079842.69),('south',1789079994.,1789079999.94)]
results={}
for name,start,end in cases:
 e=[a for a in data if a['topic']=='ego' and start-.5<=a['t']<=end+.5]
 c=[a for a in data if a['topic']=='command' and start-1<=a['t']<=end+.5]
 et=np.array([a['stamp']/1e9 for a in e]);ct=np.array([a['stamp']/1e9 for a in c])
 ep=np.array([[a['data'][k] for k in ('x','y','heading','speed')] for a in e]); ep[:,2]=np.unwrap(ep[:,2])
 cd=np.array([a['data']['steering'] for a in c])
 t=np.arange(start+.5,end-.2,.025)
 def interp(k,ts=t):return np.interp(ts,et,ep[:,k])
 # 0.2s centered finite differences and 0.025s sampling; no source timestamps from VTD itself available.
 hw=.1
 h=interp(2); omega=(interp(2,t+hw)-interp(2,t-hw))/(2*hw)
 vx=(interp(0,t+hw)-interp(0,t-hw))/(2*hw);vy=(interp(1,t+hw)-interp(1,t-hw))/(2*hw)
 v=interp(3); vl=-vx*np.sin(h)+vy*np.cos(h); vf=vx*np.cos(h)+vy*np.sin(h)
 # Smooth zero-order-held command across derivative window, and explore command-to-yaw lag.
 fits=[]
 for lag in np.arange(0,.501,.01):
  ts=t[:,None]+np.linspace(-hw,hw,21)[None,:]
  idx=np.clip(np.searchsorted(ct,ts-lag,side='right')-1,0,len(cd)-1)
  pred=np.mean(np.interp(ts,et,ep[:,3])*np.tan(cd[idx])/2.944,axis=1)
  steer=cd[np.clip(np.searchsorted(ct,t-lag,side='right')-1,0,len(cd)-1)]
  mask=(v>2)&(np.abs(pred)>.02)
  gain=float(np.dot(pred[mask],omega[mask])/np.dot(pred[mask],pred[mask]));err=omega[mask]-gain*pred[mask]
  fits.append(dict(lag=float(lag),gain=gain,rmse=float(np.sqrt(np.mean(err**2))),p10p50p90=np.quantile(omega[mask]/pred[mask],[.1,.5,.9]).tolist(),samples=int(mask.sum())))
 best=min(fits,key=lambda x:x['rmse'])
 offset_mask=(v>2)&(abs(omega)>.02)
 lateral_offset=float(np.dot(omega[offset_mask],vl[offset_mask])/np.dot(omega[offset_mask],omega[offset_mask]))
 out=dict(start=start,end=end,best=best,fits=[f for f in fits if round(f['lag'],2) in [0,.05,.1,.15,.2,.25,.3,.4,.5]],lateral_reference_offset_fit_m=lateral_offset,lateral_velocity_p10p50p90=np.quantile(vl[offset_mask],[.1,.5,.9]).tolist(),velocity_heading_minus_body_p10p50p90=np.quantile(np.arctan2(vl[offset_mask],vf[offset_mask]),[.1,.5,.9]).tolist(),xy_speed_vs_reported_ratio_p10p50p90=np.quantile(np.hypot(vx[offset_mask],vy[offset_mask])/v[offset_mask],[.1,.5,.9]).tolist(),observed_yaw_delta=float(interp(2,np.array([end-.2]))[0]-interp(2,np.array([start+.5]))[0]))
 # Repeat best-lag prediction with exact smoothed held commands.
 ts=t[:,None]+np.linspace(-hw,hw,21)[None,:]
 idx=np.clip(np.searchsorted(ct,ts-best['lag'],side='right')-1,0,len(cd)-1)
 pred=np.mean(np.interp(ts,et,ep[:,3])*np.tan(cd[idx])/2.944,axis=1)
 bins=[]
 for lo,hi in [(2,4),(4,6),(6,7),(7,8),(8,9)]:
  m=(v>=lo)&(v<hi)&(abs(pred)>.02)
  if not m.any():continue
  bins.append(dict(speed_range=[lo,hi],samples=int(m.sum()),ls_gain=float(pred[m]@omega[m]/(pred[m]@pred[m])),ratio_quantiles=np.quantile(omega[m]/pred[m],[.1,.5,.9]).tolist(),lateral_reference_offset_fit_m=float(omega[m]@vl[m]/(omega[m]@omega[m]))))
 out['speed_bins']=bins
 m=(v>2)&(abs(pred)>.02)
 q=np.linspace(0,.01,1001)
 errors=np.array([np.mean((omega[m]-pred[m]/(1+k*v[m]**2))**2) for k in q])
 j=int(np.argmin(errors));out['descriptive_speed_gain_fit']=dict(form='1 / (1 + K * v^2)',K=float(q[j]),rmse=float(np.sqrt(errors[j])),warning='Observational descriptive fit, not calibrated model or proposed production constant')
 results[name]=out
 rows=[]
 for ti in np.arange(start+1,end,.5):
  j=int(np.argmin(abs(t-ti)));delta=cd[np.clip(np.searchsorted(ct,t[j]-.1,side='right')-1,0,len(cd)-1)];pred=v[j]*np.tan(delta)/2.944
  rows.append(dict(t=float(t[j]),speed=float(v[j]),delta_lag100ms=float(delta),yawrate=float(omega[j]),pred=float(pred),ratio=float(omega[j]/pred) if abs(pred)>1e-8 else None,lateral_velocity=float(vl[j])))
 out['samples_500ms']=rows
 print(name,json.dumps({k:out[k] for k in ('best','speed_bins','descriptive_speed_gain_fit')},indent=2))
(P/'steering_response.json').write_text(json.dumps(results,indent=2))
