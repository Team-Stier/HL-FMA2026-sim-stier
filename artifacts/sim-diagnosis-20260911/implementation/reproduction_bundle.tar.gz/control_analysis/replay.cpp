#include "control/controller_core.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
int main(){
 std::ifstream f("/tmp/sim_fix_20260911/control_analysis/replay_input.txt");
 control::ReferenceBuilder builder({});control::MpcConfig cfg;cfg.maximum_solve_time_ms=1000;control::LateralMpc mpc(cfg);std::vector<double> warm;
 int id,n;double t,v,prev;control::Pose2 ego;control::PathSnapshot path;
 std::cout<<std::setprecision(15);
 while(f>>id>>t>>v>>ego.x>>ego.y>>ego.yaw>>path.capture_pose_map.x>>path.capture_pose_map.y>>path.capture_pose_map.yaw>>path.stamp_seconds>>prev>>n){
  path.points_at_capture.resize(n);for(auto &p:path.points_at_capture)f>>p.x>>p.y;
  auto r=builder.prepare(path,ego,v,.05,20);auto result=mpc.solve(r.lateral_error_m,r.heading_error_rad,v,r.curvature,prev,warm.empty()?nullptr:&warm);
  std::cout<<"{\"id\":"<<id<<",\"valid\":"<<(r.valid?"true":"false")<<",\"stop_only\":"<<(r.stop_only?"true":"false")<<",\"error\":\""<<r.error<<"\",\"ey\":"<<r.lateral_error_m<<",\"epsi\":"<<r.heading_error_rad<<",\"remaining\":"<<r.remaining_length_m<<",\"success\":"<<(result.success?"true":"false")<<",\"solver_steer\":"<<result.steering_rad<<",\"iterations\":"<<result.iterations<<",\"kappa\":[";
  for(size_t i=0;i<r.curvature.size();++i){if(i)std::cout<<",";std::cout<<r.curvature[i];}std::cout<<"]}\n";
  if(result.success){warm=result.solution;std::rotate(warm.begin(),warm.begin()+1,warm.end());if(warm.size()>1)warm.back()=warm[warm.size()-2];}else warm.clear();
 }
}
