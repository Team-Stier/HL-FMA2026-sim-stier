import json,math
from pathlib import Path
import hdmap
out=Path('/tmp/sim_fix_20260911/control_analysis');rows=[json.loads(x) for x in (out/'combined.jsonl').open()];model=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin');m=model.laneletMap();reference=[(p.x,p.y) for ident in [28004,28075,28078,29001] for p in m.laneletLayer[ident].centerline]
def projection(x,y,yaw,pts):
 best=None
 for i,(a,b) in enumerate(zip(pts,pts[1:])):
  dx,dy=b[0]-a[0],b[1]-a[1];sq=dx*dx+dy*dy
  if sq<1e-8:continue
  h=math.atan2(dy,dx)
  if abs(math.remainder(yaw-h,2*math.pi))>math.pi/2:continue
  r=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/sq));nx,ny=a[0]+r*dx,a[1]+r*dy;dist=math.hypot(x-nx,y-ny)
  item={'distance':dist,'signed':(dx*(y-ny)-dy*(x-nx))/math.sqrt(sq),'heading_error_deg':math.degrees(math.remainder(yaw-h,2*math.pi)),'index':i}
  if best is None or dist<best['distance']:best=item
 return best
paths=[]
for ln in open('/tmp/sim_fix_20260911/events.jsonl'):
 a=json.loads(ln)
 if a['topic']!='path' or not 1789079833.8<a['t']<1789079842.7 or not a['data']['points']:continue
 c=a['data']['capture'];cs,ss=math.cos(c['heading']),math.sin(c['heading']);a['world']=[(c['x']+cs*p[0]-ss*p[1],c['y']+ss*p[0]+cs*p[1]) for p in a['data']['points']];paths.append(a)
fixed=[min(paths,key=lambda a:abs(a['t']-t)) for t in [1789079834,1789079837,1789079840,1789079842.6]]
for r in rows:
 e=r['ego'];r['centerline']=projection(e['x'],e['y'],e['heading'],reference);r['fixed_paths']=[{'path_t':p['t'],'projection':projection(e['x'],e['y'],e['heading'],p['world'])} for p in fixed]
(out/'geometry_combined.jsonl').write_text('\n'.join(json.dumps(x) for x in rows)+'\n')
for t in range(1789079834,1789079843):
 r=min(rows,key=lambda a:abs(a['t']-t));print(round(r['t'],3),'centerline',r['centerline'],'fixedearly',r['fixed_paths'][0])
for p in fixed:
 c=p['data']['capture'];print('fixed path',p['t'],'start',p['world'][0],'end',p['world'][-1],'n',len(p['world']),'startcenter',projection(*p['world'][0],c['heading'],reference),'endcenter',projection(*p['world'][-1],c['heading']+2*math.atan2(p['data']['points'][-1][2],p['data']['points'][-1][3]),reference))
