import json,math,collections,bisect
from pathlib import Path
p=Path('/tmp/sim_fix_20260911')
actions=[json.loads(s) for s in (p/'actions.jsonl').read_text().splitlines()]
cases=[a for a in actions if a.get('action')=='start_updated_planner']
starts=[a['t'] for a in cases]
ends=[next((v['t'] for v in actions if v['t']>a['t'] and v.get('action')=='controller_clean_stop'), float('inf')) for a in cases]
res=[dict(name=a['case'],start=a['t'],states=collections.Counter(),caps=collections.Counter(),speed_max=0,moving_samples=0,path_n=0,path_valid=0,lengths=[],fault_accel_positive=0,max_abs_steering=0,cap_overspeed_max=0,first_no_path_after_active=None,last_ego=None) for a in cases]
last_state='';last_cap=None;active=False;pending=None
for line in (p/'events.jsonl').open():
 try:r=json.loads(line)
 except:continue
 i=bisect.bisect_right(starts,r['t'])-1
 if i<0 or r['t']>ends[i]:continue
 s=res[i];d=r['data'];topic=r['topic']
 if topic=='status':
  last_state=d.split()[0].removeprefix('state=');s['states'][last_state]+=1
  if pending and 0<=r['t']-pending['t']<.03 and last_state.startswith('STOP_') and pending['data']['accel']>0:s['fault_accel_positive']+=1
  pending=None
  if last_state.startswith('ACTIVE'):s['active_seen']=True
  if s.get('active_seen') and last_state=='STOP_NO_LOCAL_PATH' and s['first_no_path_after_active'] is None:s['first_no_path_after_active']=r['t']
 elif topic=='cap':last_cap=d;s['caps'][round(d,2)]+=1
 elif topic=='ego':
  s['speed_max']=max(s['speed_max'],d['speed']);s['last_ego']=d
  if d['speed']>.1:s['moving_samples']+=1
  if last_cap is not None:s['cap_overspeed_max']=max(s['cap_overspeed_max'],d['speed']-last_cap)
 elif topic=='command':
  s['max_abs_steering']=max(s['max_abs_steering'],abs(d['steering']))
  pending=r
 elif topic=='path':
  pts=d['points'];s['path_n']+=1
  if pts:
   s['path_valid']+=1;s['lengths'].append(sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(pts,pts[1:])))
for s in res:
 ls=sorted(s.pop('lengths'));s['valid_path_length_min_median_max']=[ls[0],ls[len(ls)//2],ls[-1]] if ls else None
 s['states']=dict(s['states']);s['caps']=dict(s['caps'].most_common(8))
(p/'live_summary.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
