#define main planner_main
#include "/home/stier/HL-FMA2026-sim-stier/src/path_planner/src/path_planner_node.cpp"
#undef main
#include <iostream>
#include <iomanip>
int main(){using namespace path_planner;std::cout<<std::setprecision(15);auto h=hdmap::hdmap_init("/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin");auto& m=h->laneletMap();auto rules=lanelet::traffic_rules::TrafficRulesFactory::create(lanelet::Locations::Germany,lanelet::Participants::Vehicle);auto g=lanelet::routing::RoutingGraph::build(m,*rules);PlannerConfig cfg{};
#include "/tmp/sim_fix_20260911/replay_config.inc"
IntersectionMonitor mon(m,cfg);EgoStatus e;e.x=732.83349609375;e.y=-250.51231384277344;e.z=46.900001525878906;e.heading=-2.47269868850708;
auto matched=mon.inspect(e);std::cout<<"MATCH lane="<<matched.first.id()<<" intersection="<<matched.second<<"\n";
auto near=lanelet::geometry::findNearest(m.laneletLayer,{183.1307878308055,142.04053259506597},5);std::cout<<"TARGET_NEAREST ";for(auto& n:near)std::cout<<n.second.id()<<":"<<n.first<<" ";std::cout<<"\n";
auto cp0=lanelet::geometry::findNearest(m.laneletLayer,{-43.67190624787195,34.998842047847965},1).front().second;auto target=near.front().second;std::cout<<"FIRST_CHECKPOINT "<<cp0.id()<<"\n";
for(auto id:{528793,528611,2534,3307,4119,4843,5027}){auto l=m.laneletLayer.get(id);auto c=l.centerline3d();double length=0.;for(size_t i=1;i<c.size();++i)length+=(c[i].basicPoint2d()-c[i-1].basicPoint2d()).norm();std::cout<<"LANE "<<id<<" length="<<length<<" z_first="<<c.front().z()<<" z_mid="<<c[c.size()/2].z()<<" z_last="<<c.back().z()<<" following=";for(auto n:g->following(l))std::cout<<n.id()<<",";auto rt=g->shortestPath(l,target);std::cout<<" TARGET_ROUTE ";if(rt)for(auto n:*rt)std::cout<<n.id()<<",";else std::cout<<"NONE";auto via=g->shortestPathVia(l,{cp0},target);std::cout<<" VIA_CP0_ROUTE ";if(via)for(auto n:*via)std::cout<<n.id()<<",";else std::cout<<"NONE";std::cout<<"\n";}
if(matched.first.id()) {std::cout<<"MATCHED_ROUTE ";auto rt=g->shortestPath(matched.first,target);if(rt)for(auto n:*rt)std::cout<<n.id()<<",";else std::cout<<"NONE";std::cout<<"\n";}
for(auto id:{528793,528611,2534,3307,4119,4843,5027}){auto l=m.laneletLayer.get(id);auto c=l.centerline3d();size_t i=c.size()/2;auto a=c[i-1],b=c[i];EgoStatus ep;ep.x=.5*(a.x()+b.x());ep.y=.5*(a.y()+b.y());ep.z=.5*(a.z()+b.z());ep.heading=atan2(b.y()-a.y(),b.x()-a.x());std::cout<<"POSE lane="<<id<<" actual="<<mon.inspect(ep).first.id()<<" x="<<ep.x<<" y="<<ep.y<<" z="<<ep.z<<" yaw="<<ep.heading<<"\n";}
}
