from pathlib import Path
import json,gzip,shlex,subprocess
root=Path('/home/stier/HL-FMA2026-sim-stier');p=Path('/tmp/recovery_failure');d=Path('/tmp/sim_fix_20260911')
s=(root/'src/path_planner/src/path_planner_node.cpp').read_text().replace('private:','public:')
s=s.replace('struct LateralProfile {','double diagnostic_lateral_scale=1.;\nstruct LateralProfile {').replace('std::max(6.,speed*duration)','std::max(6.,speed*duration*diagnostic_lateral_scale)')
(p/'planner.cpp').write_text(s);(p/'config.inc').write_text((d/'replay_config.inc').read_text())
metas=[json.loads((d/'snapshots'/(stamp+'.json')).read_text()) for stamp in ['1789080708329900653','1789080711408945837','1789080713449244494']]
rows=[]
for m in metas:
 stamp=str(m['stamp']);f=p/(stamp+'.dynamic.cdr');f.write_bytes(gzip.decompress((d/'snapshots'/(stamp+'.dynamic.cdr.gz')).read_bytes()));e=m['ego'];rows.append((stamp,e,str(f)))
for line in (d/'events.jsonl').open():
 r=json.loads(line)
 if r.get('topic')=='path' and r.get('stamp') in [1789080713089044616,1789080713289339454]:
  rows.append((str(r['stamp']),r['data']['capture'],str(p/'1789080711408945837.dynamic.cdr')))
with (p/'inputs.txt').open('w') as f:
 for stamp,e,dynamic in sorted(rows): f.write(' '.join([stamp,*[str(e[k]) for k in ['x','y','z','heading','speed']],dynamic])+'\n')
flags={line.split(' = ')[0]:shlex.split(line.split(' = ',1)[1]) for line in (root/'build/path_planner/CMakeFiles/cost_check.dir/flags.make').read_text().splitlines() if ' = ' in line};link=shlex.split((root/'build/path_planner/CMakeFiles/cost_check.dir/link.txt').read_text())
cmd=['/usr/bin/c++','-O2','-std=c++17',*flags['CXX_DEFINES'],*flags['CXX_INCLUDES'],str(p/'probe.cpp'),'-o',str(p/'probe'),*link[link.index('-o')+2:]]
r=subprocess.run(cmd,stdout=(p/'compile.log').open('w'),stderr=subprocess.STDOUT);print('compile',r.returncode)
