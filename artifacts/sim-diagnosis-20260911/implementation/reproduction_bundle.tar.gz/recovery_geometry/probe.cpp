#define main unused_main
#include "planner.cpp"
#undef main
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace path_planner;
DynamicStatus read(const std::string& file) {
 std::ifstream input(file,std::ios::binary);std::vector<char> bytes{std::istreambuf_iterator<char>(input),{}};
 rclcpp::SerializedMessage message(bytes.size());auto& buffer=message.get_rcl_serialized_message();
 std::memcpy(buffer.buffer,bytes.data(),bytes.size());buffer.buffer_length=bytes.size();
 DynamicStatus result;rclcpp::Serialization<DynamicStatus>{}.deserialize_message(&message,&result);return result;
}
int main(int argc,char** argv) {
 rclcpp::init(argc,argv);std::cout<<std::setprecision(9);PlannerConfig cfg{};
 #include "config.inc"
 auto map=hdmap::hdmap_init("/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin");
 auto rules=lanelet::traffic_rules::TrafficRulesFactory::create(lanelet::Locations::Germany,lanelet::Participants::Vehicle);
 auto graph=lanelet::routing::RoutingGraph::build(map->laneletMap(),*rules);
 ReferenceBuilder builder(map->laneletMap(),*graph);IntersectionMonitor monitor(map->laneletMap(),cfg);
 FrenetPlanner planner(*map,*graph,cfg,nullptr,nullptr);VelocityPlanner velocity(*map,cfg);CollisionValidator validator(*map,cfg);CostEvaluator costs(cfg);
 std::ifstream inputs("/tmp/recovery_failure/inputs.txt");std::string stamp,dynamic;PlanningSnapshot s;
 while(inputs>>stamp>>s.ego.x>>s.ego.y>>s.ego.z>>s.ego.heading>>s.ego.speed>>dynamic) {
  const auto ns=std::stoll(stamp);s.ego.header.stamp.sec=ns/1000000000;s.ego.header.stamp.nanosec=ns%1000000000;
  s.dynamic=std::make_shared<DynamicStatus>(read(dynamic));s.global_path={28004,28075,28078,29001};s.route_history={};
  auto current=monitor.inspect(s.ego,s.global_path);s.current_lane=current.first.id();s.goal_lanes={s.current_lane};
  auto found=std::find(s.global_path.begin(),s.global_path.end(),s.current_lane);if(found==s.global_path.end()){std::cout<<stamp<<" missing current="<<s.current_lane<<"\n";continue;}
  s.route_history.insert(s.route_history.end(),s.global_path.begin(),found);s.global_path.erase(s.global_path.begin(),found);
  const auto refs=builder.build(s,55.808,6.04);if(refs.references.empty()){std::cout<<stamp<<" no refs\n";continue;}
  const auto& common=refs.references.front();auto init=project(common,{s.ego.x,s.ego.y});
  std::cout<<"SNAP "<<stamp<<" xy="<<s.ego.x<<","<<s.ego.y<<" d="<<init.d<<" heading="<<wrap(s.ego.heading-init.yaw)<<"\n";
  for(double scale:{1.,.5,.25}) {
   diagnostic_lateral_scale=scale;auto candidates=planner.generate(s,refs.references);int road_bad=0,velocity_bad=0,collision_bad=0,valid=0;double best=1e100;Primitive winner;
   for(std::size_t k=0;k<candidates.size();++k) {
    auto p=candidates[k];auto& ref=refs.references[p.reference_index];bool covered=true;
    for(std::size_t i=0;i<p.x_m.size();++i) {
     const auto road=roadSample(*map,cfg,ref,p.x_m[i],p.y_m[i],p.yaw_rad[i],p.z_m[i],p.reference_s[i]);
     if(!road.covered){covered=false;++road_bad;if(scale==1.)std::cout<<" BAD "<<k<<" index="<<i<<" ds="<<p.reference_s[i]-ref.ego_s<<" d="<<p.centerline_offset_m[i]<<" curv="<<p.curvature_per_m[i]<<" cells="<<road.cells.size()<<"\n";break;}
    }
    if(!covered)continue;if(!velocity.plan(p,s,ref)){++velocity_bad;continue;}
    const auto h=validator.firstCollision(p,s,ref);if(h.forbidden_lane || h.index<p.x_m.size()){++collision_bad;continue;}
    ++valid;const double c=costs.evaluate(p,common,std::min(common.ego_s+50.,common.length()-3.808));if(c<best){best=c;winner=p;}
   }
   std::cout<<" RESULT scale="<<scale<<" generated="<<candidates.size()<<" road_bad="<<road_bad<<" velocity_bad="<<velocity_bad<<" collision_bad="<<collision_bad<<" valid="<<valid<<" length="<<pathLength(winner)<<" d_samples=";
   for(double distance:{0.,2.,5.,10.,15.,20.}) {
    if(winner.x_m.empty())break;double arc=0.;std::size_t i=0;for(;i+1<winner.x_m.size();++i){if(arc>=distance)break;arc+=std::hypot(winner.x_m[i+1]-winner.x_m[i],winner.y_m[i+1]-winner.y_m[i]);}
    std::cout<<"["<<distance<<","<<winner.centerline_offset_m[i]<<","<<winner.curvature_per_m[i]<<"]";
   }std::cout<<"\n";
  }
 }
 rclcpp::shutdown();
}
