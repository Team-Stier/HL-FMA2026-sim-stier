import json,time,subprocess
from pathlib import Path
out=Path('/tmp/sim_diagnosis_extended')
cases=json.loads((out/'drive_cases.json').read_text())
if isinstance(cases,dict):cases=cases.get('cases',cases.get('poses',[]))
for c in cases:(out/(c['name']+'.json')).write_text(json.dumps(c))
sequence=cases[1:]
f=(out/'events.jsonl').open();f.seek(0,2)
last=None;stop_since=None;start=time.time();index=0
print('SWEEP_READY', [c['name'] for c in sequence],flush=True)
while index<len(sequence):
 line=f.readline()
 if not line:time.sleep(.1);continue
 try:r=json.loads(line)
 except json.JSONDecodeError:continue
 if r['topic']!='summary':continue
 last=r['data'];now=r['t']
 stopped=last['ego']['speed']<.15 and last.get('path_age',0)>2 and 'STOP_NO_LOCAL_PATH' in (last.get('state') or '')
 stop_since=(stop_since or now) if stopped else None
 if (out/'pause_sweep').exists():continue
 if now-start<12:continue
 if (stop_since and now-stop_since>8) or now-start>110:
  case=sequence[index];index+=1
  why='stalled' if stop_since else 'time_budget'
  with (out/'actions.jsonl').open('a') as a:a.write(json.dumps({'t':time.time(),'action':'sweep_next_case','reason':why,'previous':last,'case':case['name'],'index':index})+'\n')
  print('NEXT',index,case['name'],why,flush=True)
  subprocess.run(['python3',str(out/'start_case.py'),str(out/(case['name']+'.json'))],check=True)
  start=time.time();stop_since=None
print('SWEEP_LAST_CASE_RUNNING',flush=True)
