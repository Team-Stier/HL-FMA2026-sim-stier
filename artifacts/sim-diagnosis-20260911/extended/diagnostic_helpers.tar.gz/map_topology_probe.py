import json,math,statistics
from pathlib import Path
import numpy as np, hdmap,lanelet2
O=Path('/tmp/sim_diagnosis_extended')
m=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin').laneletMap()
g=lanelet2.routing.RoutingGraph(m,lanelet2.traffic_rules.create(lanelet2.traffic_rules.Locations.Germany,lanelet2.traffic_rules.Participants.Vehicle))
def stats(l):
 ps=list(l.centerline); a=np.array([[p.x,p.y,p.z] for p in ps]); ds=np.linalg.norm(np.diff(a[:,:2],axis=0),axis=1);s=np.r_[0,np.cumsum(ds)]; n=len(ds)//2
 yaws=np.arctan2(np.diff(a[:,1]),np.diff(a[:,0])); turns=np.arctan2(np.sin(np.diff(yaws)),np.cos(np.diff(yaws)))
 return {'id':l.id,'attrs':dict(l.attributes),'length':float(s[-1]),'xyz':np.mean(a[n:n+2],axis=0).tolist(),'yaw':float(yaws[n]),'turn':float(sum(turns)),'abs_turn':float(sum(abs(turns))),'grade':float((a[-1,2]-a[0,2])/s[-1]),'midgrade':float((a[n+1,2]-a[n,2])/max(ds[n],1e-9)),'start':a[0].tolist(),'end':a[-1].tolist()}
records={l.id:stats(l) for l in m.laneletLayer}
lengths=np.array([r['length'] for r in records.values()]); ordinary=np.array([r['length'] for r in records.values() if r['attrs']['intersection']=='no'])
summary={'lane_count':len(records),'intersection_count':len(records)-len(ordinary),'quantiles_all':dict(zip(['min','p1','p5','p10','p25','p50','p75','p90','p95','p99','max'],np.quantile(lengths,[0,.01,.05,.10,.25,.5,.75,.9,.95,.99,1]).tolist())),'counts_below_m':{str(x):int(sum(lengths<x)) for x in [.2,.5,1,2,4.848,8,10,20,50]},'ordinary_below2':int(sum(ordinary<2))}
print('SUMMARY',json.dumps(summary))
def route(id,via=True):
 l=m.laneletLayer[id]; cp=m.laneletLayer[401819];goal=m.laneletLayer[463065]
 if via:
  a,b=g.shortestPath(l,cp),g.shortestPath(cp,goal)
  return [] if a is None or b is None else [n.id for n in a]+[n.id for n in b][1:]
 p=g.shortestPath(l,goal)
 return [] if p is None else [a.id for a in p]
def selected(id,rt):
 ids=[a.id for a in g.following(m.laneletLayer[id],False)]
 if not ids:return None
 match=next((a for a in rt[rt.index(id)+1:rt.index(id)+11] if a in ids),None) if id in rt else None
 return match or ids[0]
def chain(id,rt,budget=90):
 result=[]
 while id and id not in result and sum(records[a]['length'] for a in result)<budget:
  result.append(id);id=selected(id,rt)
 return result
hotspots=[]
for id in [401819,401650,401647,401618,401613,27224,27227,28075,28078,96120,96205,34407]:
 r=dict(records[id]);r['previous']=[a.id for a in g.previous(m.laneletLayer[id],False)];r['following']=[a.id for a in g.following(m.laneletLayer[id],False)]
 rt=route(id,id not in [401819,401650,401647,401618,401613]);r['route_start']=rt[:12];r['chain']=chain(id,rt);r['chain_lengths']=[records[a]['length'] for a in r['chain']];r['first2_reference_m']=sum(r['chain_lengths'][:2]);hotspots.append(r)
 print('HOTSPOT',id,'first2',round(r['first2_reference_m'],3),'chain',list(zip(r['chain'],[round(a,3) for a in r['chain_lengths']])),'route',rt[:8])
sweeps=[]
# Candidate starts: long ordinary lanes in varied map sectors, curved lanes and steep grades.
cs=[]
for id,r in records.items():
 if r['attrs']['intersection']!='no' or r['length']<35:continue
 cs.append(r)
print('BOUNDS',np.min([r['xyz'] for r in cs],axis=0).tolist(),np.max([r['xyz'] for r in cs],axis=0).tolist())
for name,pool,key in [('west',cs,lambda a:a['xyz'][0]),('east',cs,lambda a:-a['xyz'][0]),('north',cs,lambda a:-a['xyz'][1]),('south',cs,lambda a:a['xyz'][1]),('curves',cs,lambda a:-a['abs_turn']),('uphill',cs,lambda a:-a['midgrade']),('downhill',cs,lambda a:a['midgrade'])]:
 print('CANDIDATES',name)
 for r in sorted(pool,key=key)[:8]:print(json.dumps({k:r[k] for k in ['id','length','xyz','yaw','turn','grade','midgrade','attrs']}))
(O/'map_topology.json').write_text(json.dumps({'summary':summary,'hotspots':hotspots,'sweeps':sweeps,'lanes':records},indent=2))
