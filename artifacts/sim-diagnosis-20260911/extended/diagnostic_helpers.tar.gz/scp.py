import socket,struct,time,json,sys
from pathlib import Path
s=socket.create_connection(('127.0.0.1',48179),timeout=3);s.settimeout(.3)
def send(xml):
    b=xml.encode();s.sendall(struct.pack('<HH64s64sI',40108,1,b'CodexDiagnosis',b'any',len(b))+b)
    with Path('/tmp/sim_diagnosis_extended/actions.jsonl').open('a') as f:f.write(json.dumps({'t':time.time(),'scp':xml})+'\n')
    print('SENT',xml,flush=True)
if sys.argv[1]=='restart':
    send('<SimCtrl><Stop/><LoadScenario filename="HL_FMA_VTD_LivingLab.xml"/><Init mode="operation"/></SimCtrl>')
    buf=b'';ready=False;end=time.monotonic()+20
    while time.monotonic()<end and not ready:
        try:buf+=s.recv(65536)
        except socket.timeout:continue
        while len(buf)>=136:
            _,_,_,_,n=struct.unpack('<HH64s64sI',buf[:136])
            if len(buf)<136+n:break
            data=buf[136:136+n].decode(errors='replace');buf=buf[136+n:]
            if 'InitDone' in data and 'checkInitConfirmation' in data:print(data,flush=True);ready=True
    if not ready:raise SystemExit('InitDone not received; leaving stopped')
    send('<SimCtrl><Start/></SimCtrl>')
    for xml in sys.argv[2:]:send(xml)
else:
    for xml in sys.argv[1:]:send(xml)
s.close()
