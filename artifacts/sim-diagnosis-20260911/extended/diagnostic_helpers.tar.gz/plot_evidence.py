import json,math
from pathlib import Path
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import hdmap,lanelet2
O=Path('/tmp/sim_diagnosis_extended'); A=Path('/home/stier/HL-FMA2026-sim-stier/artifacts/sim-diagnosis-20260911')
plt.rcParams.update({'font.family':'Noto Sans CJK KR','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
rows=[json.loads(s) for s in Path('/tmp/control_roadscan/clean_curve_combined.jsonl').open()]; rows=[r for r in rows if 1789074327<r['t']<1789074333]
m=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin').laneletMap(); rules=lanelet2.traffic_rules.create(lanelet2.traffic_rules.Locations.Germany,lanelet2.traffic_rules.Participants.Vehicle)
fig=plt.figure(figsize=(12,7));gs=fig.add_gridspec(2,2,width_ratios=[1,1.4]);am=fig.add_subplot(gs[:,0]);ap=fig.add_subplot(gs[0,1]);ac=fig.add_subplot(gs[1,1])
for l in m.laneletLayer:
 if not rules.canPass(l):continue
 xy=np.array([(p.x,p.y) for p in l.polygon2d()])
 if xy[:,0].max()<849 or xy[:,0].min()>868 or xy[:,1].max()<-23 or xy[:,1].min()>9:continue
 am.add_patch(Polygon(xy,facecolor='#e5e9ee',edgecolor='#acb7c2',lw=.5))
 xy=np.array([(p.x,p.y) for p in l.centerline]);am.plot(xy[:,0],xy[:,1],c='#c4ccd5',lw=.7,ls='--')
am.plot([r['ego']['x'] for r in rows],[r['ego']['y'] for r in rows],c='#c53838',lw=2,label='실제 후륜축 궤적')
worst=max(rows,key=lambda r:r['coverage']['outside_fraction']); first=next(r for r in rows if not all(r['coverage']['corners_on_road']))
for r,c in [(first,'#df9a1f'),(worst,'#c53838')]:
 e=r['ego'];co,si=math.cos(e['heading']),math.sin(e['heading']);xy=np.array([[e['x']+co*x-si*y,e['y']+si*x+co*y] for x,y in [(3.808,.943),(3.808,-.943),(-1.04,-.943),(-1.04,.943)]])
 am.add_patch(Polygon(xy,facecolor=c,alpha=.4,edgecolor=c,lw=2))
am.annotate('첫 모서리 이탈',xy=(first['ego']['x'],first['ego']['y']),xytext=(850,-12),arrowprops={'arrowstyle':'->','color':'#9c6a00'},color='#9c6a00')
am.annotate('차체 99.8% 도로 밖',xy=(worst['ego']['x'],worst['ego']['y']),xytext=(850,7),arrowprops={'arrowstyle':'->','color':'#c53838'},color='#c53838')
am.set(xlim=(849,868),ylim=(-23,9),xlabel='지도 X (m)',ylabel='지도 Y (m)',title='A. 정상 재시작 후에도 반복된 도로 이탈');am.set_aspect('equal');am.legend(loc='lower right',fontsize=9)
events=[json.loads(s) for s in (O/'events.jsonl').open()]; t0=1789074327
paths=[r for r in events if r['topic']=='path' and t0<r['t']<t0+6];commands=[r for r in events if r['topic']=='command' and t0<r['t']<t0+6]
length=lambda r:sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(r['data']['points'],r['data']['points'][1:]))
ap.plot([r['t']-t0 for r in paths],[length(r) for r in paths],'.-',color='#2069a8',label='발행된 경로 길이');ap.set(title='B. 경로 축소 → 급조향 → 도로 이탈',ylabel='로컬 경로 길이 (m)',xlim=(0,6),ylim=(0,20));ap.legend(loc='upper right');ap.grid(alpha=.2)
ac.plot([r['t']-t0 for r in commands],[r['data']['steering'] for r in commands],color='#9847a0',label='조향 명령');ac.set(xlabel='06:05:27 KST부터 경과 시간 (s)',ylabel='조향 (rad)',xlim=(0,6),ylim=(-.53,.1));ac.grid(alpha=.2);ac.legend(loc='lower right')
for ax in [ap,ac]:
 for t,c in [(1789074329.814,'#9847a0'),(first['t'],'#df9a1f'),(worst['t'],'#c53838')]:ax.axvline(t-t0,color=c,ls='--',alpha=.65)
ap.text(2.79,18,'INVALID_PATH',rotation=90,va='top',color='#9847a0',fontsize=8)
fig.suptitle('경로가 끊긴 뒤의 제어 동작이 도로 이탈을 확대함',fontsize=15);fig.tight_layout();fig.savefig(A/'extended_road_departure.png',dpi=160);fig.savefig(A/'extended_road_departure.svg');plt.close(fig)
records=[r for r in map(json.loads,Path('/tmp/planner_census/live_goal.results.jsonl').open()) if r.get('snapshot')=='1789073777459150537' and r.get('variant')=='baseline' and r['kind']=='candidate' and r['stage']=='valid']; selected=min(records,key=lambda r:r['cost']);longest=max(records,key=lambda r:r['final_length']);use=[selected,longest]
fig,ax=plt.subplots(figsize=(9,4.4));bottom=np.zeros(2)
for key,label,color in [('goal','가까운 목표점과 끝점 거리 비용','#e36840'),('progress','50m 미달 비용','#246ea9')]:
 vals=np.array([r['cost_terms'][key] for r in use]);ax.barh([0,1],vals,left=bottom,label=label,color=color,height=.48);bottom+=vals
for i,r in enumerate(use):ax.text(r['cost']+160,i,f"합계 {r['cost']:,.1f}",va='center')
ax.set_yticks([0,1],[f"선택: {selected['final_length']:.2f}m",f"통과했지만 미선택: {longest['final_length']:.2f}m"]);ax.invert_yaxis();ax.set(xlim=(0,22000),xlabel='후보 비용 (낮을수록 우선)',title='73.3m 기준선이 남아 있어도 15.79m 후보를 선택');ax.legend(loc='lower right');fig.text(.02,.01,'동일 ego·DynamicStatus stamp 1789073777459150537. 두 후보 모두 원본 검사 통과. 미표시 소항목은 합계에 포함.',fontsize=8);fig.tight_layout(rect=(0,.05,1,1));fig.savefig(A/'extended_candidate_cost.png',dpi=160);fig.savefig(A/'extended_candidate_cost.svg');print('plots written',A)
