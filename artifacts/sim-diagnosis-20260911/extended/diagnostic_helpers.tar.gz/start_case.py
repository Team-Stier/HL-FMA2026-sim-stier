import sys,json,os,signal,subprocess,time,math
from pathlib import Path
ROOT=Path('/home/stier/HL-FMA2026-sim-stier');OUT=Path('/tmp/sim_diagnosis_extended')
case=json.loads(Path(sys.argv[1]).read_text());name=case['name'];p=case['pose'];target=case['target']
csv=OUT/f'{name}.csv';csv.write_text(f"seq,x,y\n0,{p['x']},{p['y']}\n1,{target['x']},{target['y']}\n")
def record(action,**extra):
 with (OUT/'actions.jsonl').open('a') as f:f.write(json.dumps({'t':time.time(),'action':action,'case':name,**extra})+'\n')
old=[];controllers=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:args=(d/'cmdline').read_bytes().split(b'\0')
 except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 if args[0]==str(ROOT/'install/path_planner/lib/path_planner/path_planner_node').encode():old.append(int(d.name))
 if args[0]==str(ROOT/'install/control/lib/control/mpc_control_node').encode():controllers.append(int(d.name))
for pid in controllers:os.kill(pid,signal.SIGINT)
record('controller_clean_stop',pids=controllers)
try:
 for pid in old:os.kill(pid,signal.SIGINT)
 deadline=time.monotonic()+4
 while any(Path(f'/proc/{pid}').exists() for pid in old) and time.monotonic()<deadline:time.sleep(.1)
 if any(Path(f'/proc/{pid}').exists() for pid in old):raise RuntimeError('Old planner still running')
 xml=f'<Set entity="player" name="Ego"><PosInertial x="{p["x"]}" y="{p["y"]}" z="{p["z"]}" hDeg="{math.degrees(p["yaw"])}" pDeg="0" rDeg="0"/><Speed value="0"/></Set>'
 subprocess.run(['python3',str(OUT/'scp.py'),xml],check=True)
 time.sleep(.5)
 command=[str(ROOT/'install/path_planner/lib/path_planner/path_planner_node'),'--ros-args','-r','__node:=path_planner','--params-file',str(ROOT/'install/path_planner/share/path_planner/config/planner.yaml'),'-p',f'map_path:={ROOT}/map/hdmap.bin','-p',f'checkpoint_file:={csv}','-p','use_sim_time:=false']
 proc=subprocess.Popen(command,stdout=(OUT/f'{name}_planner.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
 (OUT/'planner.pid').write_text(str(proc.pid));record('start_fresh_original_planner',pid=proc.pid,old_pids=old,checkpoint_file=str(csv),pose=p,target=target)
 time.sleep(3)
 if proc.poll() is not None:raise RuntimeError('Planner exited; inspect log')
finally:
 deadline=time.monotonic()+4
 while any(Path(f'/proc/{pid}').exists() for pid in controllers) and time.monotonic()<deadline:time.sleep(.1)
 if any(Path(f'/proc/{pid}').exists() for pid in controllers):raise RuntimeError('Old controller still running')
 controlcmd=[str(ROOT/'install/control/lib/control/mpc_control_node'),'--ros-args','-r','__node:=mpc_control','--params-file',str(ROOT/'install/control/share/control/config/control.yaml')]
 controller=subprocess.Popen(controlcmd,stdout=(OUT/f'{name}_controller.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
 (OUT/'controller.pid').write_text(str(controller.pid));record('controller_clean_start',pid=controller.pid)
print('RUNNING',name,flush=True)
