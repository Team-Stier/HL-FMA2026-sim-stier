import json,math,html
from pathlib import Path
import hdmap,lanelet2
O=Path('/tmp/sim_diagnosis_extended'); A=Path('/home/stier/HL-FMA2026-sim-stier/artifacts/sim-diagnosis-20260911');t0=1789074327
rows=[r for r in map(json.loads,Path('/tmp/control_roadscan/clean_curve_combined.jsonl').open()) if t0<r['t']<t0+6]
events=[r for r in map(json.loads,(O/'events.jsonl').open()) if t0<r['t']<t0+6]
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1160" height="720" viewBox="0 0 1160 720"><rect width="1160" height="720" fill="#fafbfd"/><style>text{font-family:"Noto Sans CJK KR",sans-serif;fill:#253348;font-size:14px}</style>']
def text(x,y,t,size=14,c='#253348'):s.append(f'<text x="{x}" y="{y}" style="font-size:{size}px;fill:{c}">{html.escape(str(t))}</text>')
def line(x1,y1,x2,y2,c='#d5dce4',w=1,dash=''):s.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{c}" stroke-width="{w}" stroke-dasharray="{dash}"/>')
def polygon(xy,fill,stroke='#a7b3c1',opacity=1):s.append('<polygon points="'+' '.join(f'{x:.2f},{y:.2f}' for x,y in xy)+f'" fill="{fill}" stroke="{stroke}" stroke-width="1" opacity="{opacity}"/>')
def polyline(xy,c,w=2):s.append('<polyline points="'+' '.join(f'{x:.2f},{y:.2f}' for x,y in xy)+f'" fill="none" stroke="{c}" stroke-width="{w}"/>')
def dot(x,y,c,r=3):s.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}"/>')
text(32,40,'경로 축소와 도로 이탈 — 원본 제어기 재시작 후 재현',25);text(32,67,'2026-09-11 06:05:27–33 KST · 지도 기반 차체 검사 · 진단용 소스 변경 없음',14)
text(40,105,'A. 실제 주행 궤적과 차체',19);mx=lambda x:40+(x-849)*17;my=lambda y:665-(y+23)*17
s.append('<defs><clipPath id="map"><rect x="40" y="121" width="323" height="544"/></clipPath></defs><g clip-path="url(#map)">')
m=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin').laneletMap();rules=lanelet2.traffic_rules.create(lanelet2.traffic_rules.Locations.Germany,lanelet2.traffic_rules.Participants.Vehicle)
for l in m.laneletLayer:
 if not rules.canPass(l):continue
 xy=[(p.x,p.y) for p in l.polygon2d()]
 if max(p[0] for p in xy)<849 or min(p[0] for p in xy)>868 or max(p[1] for p in xy)<-23 or min(p[1] for p in xy)>9:continue
 polygon([(mx(x),my(y)) for x,y in xy],'#e0e5ec')
polyline([(mx(r['ego']['x']),my(r['ego']['y'])) for r in rows],'#c6383d',2.5)
worst=max(rows,key=lambda r:r['coverage']['outside_fraction']); first=next(r for r in rows if not all(r['coverage']['corners_on_road']))
for r,c in [(first,'#de9b20'),(worst,'#c6383d')]:
 e=r['ego'];co,si=math.cos(e['heading']),math.sin(e['heading']);xy=[(mx(e['x']+co*x-si*y),my(e['y']+si*x+co*y)) for x,y in [(3.808,.943),(3.808,-.943),(-1.04,-.943),(-1.04,.943)]];polygon(xy,c,c,.55)
s.append('</g>');text(55,150,'차체 99.8% 도로 밖',17,'#b52632');text(55,175,'(861.089, 0.345)',13);line(200,183,mx(worst['ego']['x']),my(worst['ego']['y']),'#b52632')
text(50,690,'회색: 주행 가능한 도로 / 빨강: 실제 궤적',12)
text(430,105,'B. 짧아지는 경로와 급조향의 선후 관계',19)
def axes(y,h,lo,hi,ticks,title):
 x=445;w=650
 for n in range(7):
  px=x+w*n/6;line(px,y,px,y+h);text(px-4,y+h+20,n,12)
 for n in ticks:
  py=y+h-(n-lo)/(hi-lo)*h;line(x,py,x+w,py);text(x-42,py+5,n,12)
 text(x,y-13,title,14);return lambda t,v:(x+w*(t-t0)/6,y+h-(v-lo)/(hi-lo)*h)
p=axes(150,180,0,70,[0,20,40,60],'発행된 로컬 경로 길이 (m)'.replace('発','발'));q=axes(419,180,-.5,.1,[-.5,-.3,-.1,.1],'조향 명령 (rad)')
paths=[r for r in events if r['topic']=='path'];length=lambda r:sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(r['data']['points'],r['data']['points'][1:]))
segment=[]
for r in paths:
 if segment and r['t']-segment[-1]['t']>.15:
  polyline([p(v['t'],length(v)) for v in segment],'#236aab');segment=[]
 segment.append(r)
if segment:polyline([p(v['t'],length(v)) for v in segment],'#236aab')
for r in paths:dot(*p(r['t'],length(r)),'#236aab',2)
commands=[r for r in events if r['topic']=='command'];polyline([q(r['t'],r['data']['steering']) for r in commands],'#934ba2',2)
for t,c in [(1789074329.814,'#934ba2'),(first['t'],'#de9b20'),(worst['t'],'#c6383d')]:
 x=p(t,0)[0];line(x,150,x,330,c,1.5,'5 4');line(x,419,x,599,c,1.5,'5 4')
text(435,386,'파란 선의 빈 구간: 경로 발행 없음',12);text(435,365,'보라: INVALID_PATH / 주황: 첫 이탈 / 빨강: 최대 이탈',13);text(610,655,'06:05:27 KST부터 경과 시간 (s)',14);text(435,690,'급조향: -0.035 → -0.480 rad. 이후 정상 복귀도 0.02 rad/주기로 제한.',13)
s.append('</svg>');(A/'extended_road_departure.svg').write_text('\n'.join(s))
records=[r for r in map(json.loads,Path('/tmp/planner_census/live_goal.results.jsonl').open()) if r.get('snapshot')=='1789073777459150537' and r.get('variant')=='baseline' and r['kind']=='candidate' and r['stage']=='valid'];short=min(records,key=lambda r:r['cost']);long=max(records,key=lambda r:r['final_length'])
s[:]=['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="390"><rect width="1100" height="390" fill="#fafbfd"/><style>text{font-family:"Noto Sans CJK KR",sans-serif;fill:#253348;font-size:14px}</style>'];text(30,43,'73.3m 기준선이 남아 있어도 15.79m 후보를 선택',25);text(30,76,'동일 시각의 ego·DynamicStatus로 원본 계산 재현. 두 후보 모두 모든 검사를 통과.',14)
for i,r in enumerate([short,long]):
 y=120+110*i;text(30,y+30,('선택: ' if i==0 else '미선택: ')+f"{r['final_length']:.2f}m",18);x=225
 for key,color in [('goal','#df693f'),('progress','#256eaa')]:
  w=r['cost_terms'][key]/19000*690;s.append(f'<rect x="{x}" y="{y}" width="{w}" height="45" fill="{color}"/>');x+=w
 text(x+12,y+30,f"합계 {r['cost']:,.1f}",15)
text(225,326,'주황: 가까운 목표점과 끝점 거리 비용 / 파랑: 50m 미달 비용',15);text(30,370,'stamp 1789073777459150537 · 합계에는 작은 시간/횡방향 비용도 포함 · 길수록 낮은 비용이 되는 설계가 아님',12);s.append('</svg>');(A/'extended_candidate_cost.svg').write_text('\n'.join(s));print('SVG written',A)
