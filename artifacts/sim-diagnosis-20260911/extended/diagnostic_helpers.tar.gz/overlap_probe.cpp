#define main planner_main
#include "/home/stier/HL-FMA2026-sim-stier/src/path_planner/src/path_planner_node.cpp"
#undef main
#include <iostream>
#include <iomanip>
int main(){using namespace path_planner;auto map=hdmap::hdmap_init("/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin");PlannerConfig cfg{};cfg.rear_axle_to_front_m=3.808;cfg.rear_axle_to_rear_m=1.040;cfg.left_extent_m=.943;cfg.right_extent_m=.943;IntersectionMonitor mon(map->laneletMap(),cfg);double x,y,z,h;std::cout<<std::setprecision(12);
while(std::cin>>x>>y>>z>>h){EgoStatus e;e.x=x;e.y=y;e.z=z;e.heading=h;std::cout<<"POSE "<<x<<" "<<y<<" "<<z<<" "<<h<<" current="<<mon.inspect(e).first.id()<<"\n";auto p=footprint(x,y,h,cfg);auto box=lanelet::geometry::boundingBox2d(p);
for(auto l:map->laneletMap().laneletLayer.search(box)){auto lp=l.polygon2d().basicPolygon();bool overlap=boost::geometry::overlaps(lp,p),inside=boost::geometry::within(p.front(),lp);std::vector<lanelet::BasicPolygon2d> ints;boost::geometry::intersection(lp,p,ints);double ar=0;for(auto a:ints)ar+=abs(boost::geometry::area(a));if(ar<1e-8)continue;double best=1e100,dz=0,yaw=0,nearx=0,neary=0;auto cl=l.centerline();for(size_t i=1;i<cl.size();++i){auto a=cl[i-1],b=cl[i];double dx=b.x()-a.x(),dy=b.y()-a.y();double q=std::clamp(((x-a.x())*dx+(y-a.y())*dy)/(dx*dx+dy*dy),0.,1.);double xx=a.x()+q*dx,yy=a.y()+q*dy;double dd=hypot(x-xx,y-yy);if(dd<best){best=dd;dz=a.z()+q*(b.z()-a.z())-z;yaw=atan2(dy,dx);nearx=xx;neary=yy;}}
std::cout<<"LANE "<<l.id()<<" area="<<ar<<" accepted="<<(overlap||inside)<<" overlap="<<overlap<<" corner_in="<<inside<<" centerline_dist="<<best<<" lane_minus_ego_z="<<dz<<" lane_yaw="<<yaw<<" yaw_error="<<atan2(sin(h-yaw),cos(h-yaw))<<" nearest="<<nearx<<","<<neary<<" attrs=";for(auto& a:l.attributes())std::cout<<a.first<<":"<<a.second.value()<<";";std::cout<<"\n";}
}}
