#define main planner_main
#include "/home/stier/HL-FMA2026-sim-stier/src/path_planner/src/path_planner_node.cpp"
#undef main
#include <iostream>
int main(){using namespace path_planner;auto map=hdmap::hdmap_init("/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin");PlannerConfig cfg{};cfg.rear_axle_to_front_m=3.808;cfg.rear_axle_to_rear_m=1.040;cfg.left_extent_m=.943;cfg.right_extent_m=.943;IntersectionMonitor mon(map->laneletMap(),cfg);
for(auto id:{401819,27224,28075,96120}){auto l=map->laneletMap().laneletLayer.get(id);auto p=l.centerline2d();auto a=p[p.size()-2],b=p.back();double yaw=atan2(b.y()-a.y(),b.x()-a.x());lanelet::Id last=0;
for(int n=-50;n<=50;++n){double d=n*.1;EgoStatus e;e.x=b.x()+d*cos(yaw);e.y=b.y()+d*sin(yaw);e.heading=yaw;auto cur=mon.inspect(e);if(cur.first.id()!=last)std::cout<<"SWITCH upstream="<<id<<" distance_to_end="<<d<<" current="<<cur.first.id()<<" intersection="<<cur.second<<"\n";last=cur.first.id();}}
// Pose checks read numeric rows from stdin, never interact with the simulator.
long id;double x,y,z,yaw;while(std::cin>>id>>x>>y>>z>>yaw){EgoStatus e;e.x=x;e.y=y;e.z=z;e.heading=yaw;auto c=mon.inspect(e);std::cout<<"POSE expected="<<id<<" actual="<<c.first.id()<<" intersection="<<c.second<<"\n";}}
