import time,json,gzip,math
from pathlib import Path
import rclpy
from rclpy.qos import QoSProfile,ReliabilityPolicy
from rclpy.serialization import serialize_message
from interfaces.msg import SearchTree
rclpy.init();node=rclpy.create_node('diagnostic_candidate_tree_observer')
out=Path('/tmp/sim_diagnosis_extended');f=(out/'trees.jsonl').open('a',buffering=1);lastsave=0.
def on_tree(m):
 global lastsave
 stamp=m.header.stamp.sec*1000000000+m.header.stamp.nanosec
 starts=[i for i,p in enumerate(m.parent_index) if p<0];ends=starts[1:]+[len(m.x)];candidates=[];selected=None
 for idx,(a,b) in enumerate(zip(starts,ends)):
  length=sum(math.hypot(m.x[i]-m.x[i-1],m.y[i]-m.y[i-1]) for i in range(a+1,b))
  candidates.append({'n':b-a,'length':length,'end':[m.x[b-1],m.y[b-1]],'begin':[m.x[a],m.y[a]]})
  if a<=m.final_node_index<b:selected=idx
 row={'t':time.time(),'stamp':stamp,'candidates':candidates,'selected':selected}
 f.write(json.dumps(row,separators=(',',':'))+'\n')
 if time.monotonic()-lastsave>.45:
  with gzip.open(out/'snapshots'/f'{stamp}.tree.cdr.gz','wb',compresslevel=1) as g:g.write(serialize_message(m))
  lastsave=time.monotonic()
node.create_subscription(SearchTree,'/search_tree',on_tree,QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT))
try:rclpy.spin(node)
except KeyboardInterrupt:pass
finally:f.close();node.destroy_node();rclpy.try_shutdown()
