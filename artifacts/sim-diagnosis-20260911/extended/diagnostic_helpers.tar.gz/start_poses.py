import json, math
from pathlib import Path
import numpy as np, hdmap,lanelet2
O=Path('/tmp/sim_diagnosis_extended');m=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin').laneletMap();g=lanelet2.routing.RoutingGraph(m,lanelet2.traffic_rules.create(lanelet2.traffic_rules.Locations.Germany,lanelet2.traffic_rules.Participants.Vehicle))
def shape(id):
 a=np.array([[p.x,p.y,p.z] for p in m.laneletLayer[id].centerline]);s=np.r_[0,np.cumsum(np.linalg.norm(np.diff(a[:,:2],axis=0),axis=1))];return a,s

def pose(id,st=None):
 a,s=shape(id);st=s[-1]/2 if st is None else st;i=min(len(s)-2,max(0,int(np.searchsorted(s,st,side='right'))-1));p=a[i]+(a[i+1]-a[i])*(st-s[i])/(s[i+1]-s[i]);yaw=math.atan2(a[i+1,1]-a[i,1],a[i+1,0]-a[i,0]);return {'lane':id,'x':float(p[0]),'y':float(p[1]),'z':float(p[2]),'yaw_rad':yaw,'yaw_deg':math.degrees(yaw),'station_m':st,'lane_length_m':float(s[-1])}
def follow(id):
 ns=list(g.following(m.laneletLayer[id],False))
 if not ns:return None
 a,_=shape(id);yaw=math.atan2(a[-1,1]-a[-2,1],a[-1,0]-a[-2,0]);
 def score(l):
  p,_=shape(l.id);h=math.atan2(p[1,1]-p[0,1],p[1,0]-p[0,0]);return abs(math.atan2(math.sin(h-yaw),math.cos(h-yaw)))
 return min(ns,key=score).id
cases=[]
for name,id in [('known_north_curve_road173',28004),('south_large_curve_road1909',148779),('west_steep_downhill_road1602',110407),('north_uphill_road2819',445027),('west_eastbound_intersection_road76',8862)]:
 start=pose(id,2. if id==28004 else None)
 if id==28004: target=pose(29001,105.);chain=[28004,28075,28078,29001]
 else:
  chain=[id];distance=start['lane_length_m']-start['station_m'];cur=id
  while distance<260 or dict(m.laneletLayer[cur].attributes)['intersection']=='yes':
   nxt=follow(cur)
   if nxt is None or nxt in chain:break
   cur=nxt;chain.append(cur);distance+=shape(cur)[1][-1]
  target=pose(cur)
 path=g.shortestPath(m.laneletLayer[id],m.laneletLayer[target['lane']])
 ids=[] if path is None else [l.id for l in path]
 distance=sum(float(shape(i)[1][-1]) for i in ids)-start['station_m']-(target['lane_length_m']-target['station_m']) if ids else None
 case={'name':name,'start':start,'target':target,'longitudinal_chain':chain,'shortest_path':ids,'route_centerline_distance_m':distance,'start_attrs':dict(m.laneletLayer[id].attributes)}
 cases.append(case)
(O/'start_poses.json').write_text(json.dumps(cases,indent=2))
(O/'start_pose_check.txt').write_text(''.join(f"{c['start']['lane']} {c['start']['x']} {c['start']['y']} {c['start']['z']} {c['start']['yaw_rad']}\n" for c in cases))
for c in cases:print(json.dumps(c))
