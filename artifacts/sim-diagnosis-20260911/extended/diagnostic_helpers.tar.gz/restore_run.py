from pathlib import Path
import os,signal,time,json,subprocess
R=Path('/home/stier/HL-FMA2026-sim-stier');O=Path('/tmp/sim_diagnosis_extended');old=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:a=(d/'cmdline').read_bytes().split(b'\0')
 except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 if a[0] in [str(R/'install/control/lib/control/mpc_control_node').encode(),str(R/'install/path_planner/lib/path_planner/path_planner_node').encode()]:old.append(int(d.name))
for pid in old:os.kill(pid,signal.SIGINT)
end=time.monotonic()+6
while any(Path(f'/proc/{p}').exists() for p in old) and time.monotonic()<end:time.sleep(.1)
if any(Path(f'/proc/{p}').exists() for p in old):raise SystemExit('original processes still exiting')
subprocess.run(['python3',str(O/'scp.py'),'restart'],check=True)
planner=subprocess.Popen([str(R/'install/path_planner/lib/path_planner/path_planner_node'),'--ros-args','-r','__node:=path_planner','--params-file',str(R/'install/path_planner/share/path_planner/config/planner.yaml'),'-p',f'map_path:={R}/map/hdmap.bin','-p',f'checkpoint_file:={R}/install/path_planner/share/path_planner/checkpoint/checkpoints.csv','-p','use_sim_time:=false'],stdout=(O/'restored_original_planner.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
time.sleep(3)
controller=subprocess.Popen([str(R/'install/control/lib/control/mpc_control_node'),'--ros-args','-r','__node:=mpc_control','--params-file',str(R/'install/control/share/control/config/control.yaml')],stdout=(O/'restored_original_controller.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
(O/'controller.pid').write_text(str(controller.pid));(O/'planner.pid').write_text(str(planner.pid))
with (O/'actions.jsonl').open('a') as f:f.write(json.dumps({'t':time.time(),'action':'restore_original_checkpoint_and_binaries','old_pids':old,'planner_pid':planner.pid,'controller_pid':controller.pid,'checkpoint_file':str(R/'install/path_planner/share/path_planner/checkpoint/checkpoints.csv')})+'\n')
print('RESTORED',planner.pid,controller.pid,flush=True)
