from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import json,shutil,gzip,tarfile,time
S=Path('/tmp/sim_diagnosis_extended');A=Path('/home/stier/HL-FMA2026-sim-stier/artifacts/sim-diagnosis-20260911');D=A/'extended';D.mkdir(exist_ok=True)
counts=Counter();first=None;last=None;lastsummary=None
for r in map(json.loads,(S/'events.jsonl').open()):
 counts[r['topic']]+=1;first=r['t'] if first is None else first;last=r['t']
 if r['topic']=='summary':lastsummary=r['data']
actions=[json.loads(s) for s in (S/'actions.jsonl').open()];runs=[a for a in actions if a.get('action') in ['start_fresh_original_planner','restore_original_checkpoint_and_binaries']]
summary={'start_kst':datetime.fromtimestamp(first,ZoneInfo('Asia/Seoul')).isoformat(),'end_kst':datetime.fromtimestamp(last,ZoneInfo('Asia/Seoul')).isoformat(),'duration_s':last-first,'counts':dict(counts),'run_starts':runs,'last_observed':lastsummary,'note':'Includes SIGSTOP-associated DDS affected runs; these are separated in report and excluded from normal driving findings. No product source/config/original checkpoint edits. Last run restored original checkpoint/binaries.','diagnostic_sources':['/tmp/sim_diagnosis_extended','/tmp/planner_census','/tmp/control_roadscan'],'video':'/tmp/sim_diagnosis_extended/front_scan.mkv'}
(D/'session_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(S/'session_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
for pattern in ['*.md','*findings*.json','*evidence*.json','map_topology.json','topology_extra.json','start_poses.json','drive_cases.json','signal217_stoplines.json','north_upper_to_lower.json','actions.jsonl','observer.log','clean_sweep.log','sweep.log','video_start.json','tree_statistics.json']:
 for f in S.glob(pattern):shutil.copy2(f,D/f.name)
for name in ['events.jsonl','trees.jsonl','snapshots.jsonl']:
 with (S/name).open('rb') as inp,gzip.open(D/(name+'.gz'),'wb',compresslevel=6) as out:shutil.copyfileobj(inp,out)
for name,folder in [('planner_census',Path('/tmp/planner_census')),('control_roadscan',Path('/tmp/control_roadscan'))]:
 dest=A/name;dest.mkdir(exist_ok=True)
 for f in folder.iterdir():
  if f.is_file() and (f.suffix=='.md' or f.name.endswith('summary.json') or f.name in ['validation.json','tree_validation.json','more_validation.json','cost_evidence.json','north_evidence.json','north217_stop.json','clean_departure_evidence.svg','clean_departure_evidence.png']):shutil.copy2(f,dest/f.name)
 with tarfile.open(dest/'reproduction_bundle.tar.gz','w:gz',compresslevel=6) as tar:tar.add(folder,arcname=name)
with tarfile.open(D/'diagnostic_helpers.tar.gz','w:gz',compresslevel=6) as tar:
 for f in S.iterdir():
  if f.is_file() and f.suffix in ['.py','.cpp','.csv','.txt']:tar.add(f,arcname=f.name)
p=A/'extended_report.md';s=p.read_text().replace('약15.5m','약15.6m');insert=f"## 시험 및 검증 범위\n\n- 추가 관측: **{summary['start_kst'][11:19]}–{summary['end_kst'][11:19]} KST**, {summary['duration_s']/60:.1f}분. ego {counts['ego']:,}개, 로컬 경로 {counts['path']:,}개 기록. 자동/수동 재시작과 원래 경로 복구 포함.\n- 북향 커브·남쪽 커브·서쪽 내리막·북쪽 오르막·서쪽 교차로의 5개 구간을 시험하고, 제어기를 정상 재시작한 반복 주행 및 북쪽 신호 재시험을 수행했다.\n- **31개 상태 재생:** 발행된 23개 경로의 전 좌표 오차 ≤1.21×10⁻⁶m, 원본 SearchTree 17개의 후보 개수·선택·길이 일치. 실제 무경로 8개도 재현했다. 후보 830개 중 곡률465·속도104·금지 차선52개 탈락,209개 유효.\n- 시험 종료 상태: 원본 planner/controller와 기존 checkpoint 인자를 복구했다. 마지막 차량은 **(801.328,-83.195)**, `STOP_NO_LOCAL_PATH`, 속도0이다. 진단 관측기와 자동 경로 전환만 종료했다.\n\n"
s=s.replace('## 1. 왜 경로가 짧아지는가',insert+'## 1. 왜 경로가 짧아지는가')
s=s.replace('![원본 제어기 재시작 후 도로 이탈]',f'북쪽 신호 통과 후에도 `(1445.4,868.9)` 부근에서 INVALID_PATH와 도로 이탈이 먼저 나타났다. 뒤의 위치/높이 점프는 별도 사건이며, 그 구체적 시뮬레이터 트리거까지 확인한 것은 아니다.\n\n![원본 제어기 재시작 후 도로 이탈]')
s=s.replace('## 4. 감속·신호·리스폰·목표 처리',f'![북향·남쪽의 급조향과 가속 비교]({A}/control_roadscan/clean_departure_evidence.png)\n\n## 4. 감속·신호·리스폰·목표 처리');p.write_text(s)
print(json.dumps({'start':summary['start_kst'],'end':summary['end_kst'],'minutes':summary['duration_s']/60,'counts':dict(counts),'run_starts':len(runs)},ensure_ascii=False))
