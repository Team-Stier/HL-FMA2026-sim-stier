import json,math,subprocess
from pathlib import Path
ls=[json.loads(x) for x in open('/tmp/sim_diagnosis_20260911/events.jsonl')];paths=[x for x in ls if x['topic']=='path' and x['data'].get('capture')];out=Path('/tmp/control_roadscan');metas=[];rows=[];i=0
for target in [1789070731.5,1789070732.75,1789070748.5,1789070749.5,1789070750.5,1789070751.5,1789070753.5,1789070755.5,1789070984.5,1789071001.5,1789071003.5,1789071101.5]:
 p=max((p for p in paths if p['t']<=target),key=lambda p:p['t']);capture=p['data']['capture'];cs,ss=math.cos(capture['heading']),math.sin(capture['heading']);arc=0;prev=None
 for j,pt in enumerate(p['data']['points']):
  if prev:arc+=math.hypot(pt[0]-prev[0],pt[1]-prev[1])
  prev=pt
  if arc>12:break
  i+=1;x=capture['x']+cs*pt[0]-ss*pt[1];y=capture['y']+ss*pt[0]+cs*pt[1];yaw=capture['heading']+2*math.atan2(pt[2],pt[3]);rows.append(' '.join(map(str,[i,x,y,capture['z'],yaw,capture['speed']])));metas.append({'target':target,'path_t':p['t'],'path_stamp':p['stamp'],'index':j,'arc':arc,'map_xy':[x,y],'yaw':yaw})
(out/'path_probe_input.txt').write_text('\n'.join(rows)+'\n')
with (out/'path_probe_coverage.jsonl').open('w') as f:subprocess.run(['/tmp/control_roadscan/containment',str(out/'path_probe_input.txt')],stdout=f,check=True)
coverage=[json.loads(x) for x in (out/'path_probe_coverage.jsonl').open()];combined=[dict(m,coverage=c) for m,c in zip(metas,coverage)];(out/'path_probe_combined.jsonl').write_text('\n'.join(json.dumps(x) for x in combined)+'\n')
for target in sorted(set(x['target'] for x in combined)):
 r=[x for x in combined if x['target']==target];bad=[x for x in r if not all(x['coverage']['corners_on_road'])];worst=max(r,key=lambda x:x['coverage']['outside_fraction']);print(json.dumps({'target':target,'path_t':r[0]['path_t'],'bad_points':len(bad),'n':len(r),'first_bad':bad[0] if bad else None,'worst':worst}))
