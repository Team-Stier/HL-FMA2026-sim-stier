import json,math,html,ctypes,ctypes.util
from pathlib import Path
out=Path('/tmp/control_roadscan');combined=[json.loads(x) for x in (out/'clean_sweep_combined.jsonl').open()];polys=json.loads((out/'clean_plot_polygons.json').read_text());events=[json.loads(x) for x in Path('/tmp/sim_diagnosis_extended/events.jsonl').open()]
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="1040" viewBox="0 0 1280 1040">','<rect width="1280" height="1040" fill="#f7f9fc"/>','<style>text{font-family:Arial,sans-serif;fill:#203047;font-size:14px}.title{font-size:25px;font-weight:bold}.head{font-size:18px;font-weight:bold}.small{font-size:12px}</style>']
def text(x,y,t,cl='',anchor='start',color=None):svg.append(f'<text x="{x}" y="{y}" class="{cl}" text-anchor="{anchor}"'+(f' style="fill:{color}"' if color else '')+'>'+html.escape(str(t))+'</text>')
def path(pts,color,width=2,fill='none',closed=False):svg.append('<'+('polygon' if closed else 'polyline')+' points="'+' '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+f'" fill="{fill}" stroke="{color}" stroke-width="{width}"/>')
def nearest(t):return min(combined,key=lambda a:abs(a['t']-t))
def corners(e):
 c,s=math.cos(e['heading']),math.sin(e['heading']);return [(e['x']+c*f-s*v,e['y']+s*f+c*v) for f,v in [(3.808,.943),(3.808,-.943),(-1.04,-.943),(-1.04,.943)]]
text(35,42,'Clean controller runs: short-path fallback precedes road departure','title');text(35,69,'Same original binary and settings; fresh controller process per case. Source code unchanged.')
for row,(start,end,invalid,onset,worst,title) in enumerate([(1789074328.9,1789074331.32,1789074329.814,1789074330.060,1789074331.3013,'A  Curve near (861, 0): 99.83% body outside'),(1789074415.5,1789074418.90,1789074416.392,1789074417.181,1789074418.8675,'B  South curve: 92.31% body outside')]):
 top=112+row*420;text(40,top,title,'head');text(640,top,'Commands: instant max steering, gradual recovery','head');trace=[a for a in combined if start<=a['t']<=end];xs=[p[0] for a in trace for p in corners(a['ego'])];ys=[p[1] for a in trace for p in corners(a['ego'])];xmin,xmax=min(xs)-1.2,max(xs)+1.2;ymin,ymax=min(ys)-1.2,max(ys)+1.2;x,y,w,h=40,top+24,500,315;scale=min(w/(xmax-xmin),h/(ymax-ymin));ox=x+(w-(xmax-xmin)*scale)/2;oy=y+(h-(ymax-ymin)*scale)/2
 def project(p):return ox+(p[0]-xmin)*scale,oy+h-(p[1]-ymin)*scale
 svg.append(f'<defs><clipPath id="map{row}"><rect x="{x}" y="{y}" width="{w}" height="{h}"/></clipPath></defs><rect x="{x}" y="{y}" width="{w}" height="{h}" fill="white" stroke="#c8d0d8"/><g clip-path="url(#map{row})">')
 for p in polys[str(worst)]:path([project(a) for a in p],'#889aa5',.7,'#e0e6ea',True)
 ps=[p for p in events if p['topic']=='path' and p['data'].get('capture') and p['t']<invalid-.05]
 if ps:
  p=ps[-1]['data'];e=p['capture'];c,s=math.cos(e['heading']),math.sin(e['heading']);pts=[(e['x']+c*q[0]-s*q[1],e['y']+s*q[0]+c*q[1]) for q in p['points']];path([project(q) for q in pts],'#078774',2.5)
 path([project((a['ego']['x'],a['ego']['y'])) for a in trace],'#203047',2)
 for t,color in [(invalid,'#ac7900'),(onset,'#d06415'),(worst,'#c72f4a')]:path([project(q) for q in corners(nearest(t)['ego'])],color,2.5,'none',True)
 svg.append('</g>');text(40,top+359,'Gray: vehicle-passable map; green: last pre-fallback path','small');text(40,top+380,'Body: invalid path (gold) → first corner out (orange) → worst (red)','small');text(40,top+401,'Map x / y in meters; vehicle footprint drawn to scale.','small')
 x,y,w,h=640,top+24,560,315;lo,hi=start-invalid,end-invalid
 def proj(t,v,vmin=-.5,vmax=.12):return x+(t-lo)/(hi-lo)*w,y+h-(v-vmin)/(vmax-vmin)*h
 svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="white" stroke="#c8d0d8"/>')
 for v in [-.5,-.4,-.3,-.2,-.1,0,.1]:
  xx,yy=proj(lo,v);path([(x,yy),(x+w,yy)],'#e4e8ed',1);text(x-8,yy+4,f'{v:.1f}','small','end','#425fc5')
 for v in [-3,-2,-1,0,1,2]:
  xx,yy=proj(lo,v,-3.2,2.3);text(x+w+8,yy+4,str(v),'small',color='#b73b59')
 cmd=[a for a in events if a['topic']=='command' and start<=a['t']<=end]
 for key,color,mn,mx in [('steering','#425fc5',-.5,.12),('accel','#b73b59',-3.2,2.3)]:
  pts=[]
  for i,a in enumerate(cmd):
   if i:pts.append(proj(a['t']-invalid,cmd[i-1]['data'][key],mn,mx))
   pts.append(proj(a['t']-invalid,a['data'][key],mn,mx))
  path(pts,color,2.3)
 marks=[(invalid,'#ac7900','INVALID'),(onset,'#d06415','First corner out')];stops=[a for a in events if a['topic']=='status' and start<=a['t']<=end and a['data'].startswith('state=STOP_NO_LOCAL_PATH')]
 if stops:marks.append((stops[0]['t'],'#666','Timeout STOP'))
 for t,col,label in marks:
  xx,_=proj(t-invalid,0);svg.append(f'<path d="M{xx},{y}V{y+h}" stroke="{col}" stroke-dasharray="5,4"/>');text(xx+5,y+18+marks.index((t,col,label))*19,label,'small',color=col)
 for tick in range(math.ceil(lo*2),math.floor(hi*2)+1):
  v=tick*.5;xx,_=proj(v,0);text(xx,y+h+20,f'{v:.1f}','small','middle')
 text(x+w/2,y+h+43,'Seconds from first INVALID_PATH','small','middle');text(x,y+h+64,'Blue: steering (rad)','small',color='#425fc5');text(x+240,y+h+64,'Red: acceleration (m/s²)','small',color='#b73b59')
text(40,995,'Independent lanelet2.inside grid validation: 99.86% outside for A; 92.29% for B.');text(40,1018,'Recorded 2026-09-11 KST. Road-map departure is confirmed; identifying the physical sidewalk needs image/map-scene comparison.','small');svg.append('</svg>');p=out/'clean_departure_evidence.svg';p.write_text('\n'.join(svg));import xml.etree.ElementTree as ET;ET.parse(p);print(p)
# Render using installed librsvg/cairo, without adding dependencies.
rsvg=ctypes.CDLL(ctypes.util.find_library('rsvg-2'));cairo=ctypes.CDLL(ctypes.util.find_library('cairo'));rsvg.rsvg_handle_new_from_file.argtypes=[ctypes.c_char_p,ctypes.c_void_p];rsvg.rsvg_handle_new_from_file.restype=ctypes.c_void_p;cairo.cairo_image_surface_create.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int];cairo.cairo_image_surface_create.restype=ctypes.c_void_p;cairo.cairo_create.argtypes=[ctypes.c_void_p];cairo.cairo_create.restype=ctypes.c_void_p;rsvg.rsvg_handle_render_cairo.argtypes=[ctypes.c_void_p,ctypes.c_void_p];rsvg.rsvg_handle_render_cairo.restype=ctypes.c_int;cairo.cairo_surface_write_to_png.argtypes=[ctypes.c_void_p,ctypes.c_char_p];cairo.cairo_surface_write_to_png.restype=ctypes.c_int
handle=rsvg.rsvg_handle_new_from_file(str(p).encode(),None);surface=cairo.cairo_image_surface_create(0,1280,1040);ctx=cairo.cairo_create(surface);assert rsvg.rsvg_handle_render_cairo(handle,ctx);assert cairo.cairo_surface_write_to_png(surface,str(out/'clean_departure_evidence.png').encode())==0;print(out/'clean_departure_evidence.png')
