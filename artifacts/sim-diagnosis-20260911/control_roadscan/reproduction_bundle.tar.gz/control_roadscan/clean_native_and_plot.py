import json,math
from pathlib import Path
import hdmap,lanelet2.geometry as geom,lanelet2.traffic_rules as tr
from lanelet2.core import BasicPoint2d
out=Path('/tmp/control_roadscan');model=hdmap.hdmap_init('/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin');m=model.laneletMap();rules=tr.create(tr.Locations.Germany,tr.Participants.Vehicle)
combined=[json.loads(x) for x in (out/'clean_sweep_combined.jsonl').open()]
def nearest(target):return min(combined,key=lambda a:abs(a['t']-target))
def corners(e):
 c,s=math.cos(e['heading']),math.sin(e['heading'])
 return [(e['x']+c*f-s*v,e['y']+s*f+c*v) for f,v in [(3.808,.943),(3.808,-.943),(-1.04,-.943),(-1.04,.943)]]
def lanes_near(e):
 ls=[l for _,l in geom.findNearest(m.laneletLayer,BasicPoint2d(e['x'],e['y']),50) if rules.canPass(l)]
 return [l for l in ls if min(p.z for p in l.polygon3d())-2<=e['z']<=max(p.z for p in l.polygon3d())+2]
checks=[]
for t in [1789074331.3013,1789074348.6611,1789074396.1804,1789074418.8675,1789074459.26,1789074460.6999,1789074462.5006]:
 a=nearest(t);e=a['ego'];ls=lanes_near(e);c,s=math.cos(e['heading']),math.sin(e['heading']);outside=0
 for i in range(60):
  for j in range(24):
   f=-1.04+(i+.5)*4.848/60;v=-.943+(j+.5)*1.886/24;p=BasicPoint2d(e['x']+c*f-s*v,e['y']+s*f+c*v)
   outside+=not any(geom.inside(l,p) for l in ls)
 checks.append({'t':a['t'],'xy':[e['x'],e['y']],'union_outside_fraction':a['coverage']['outside_fraction'],'native_grid_outside_fraction':outside/(60*24),'lanes':[l.id for l in ls]})
(out/'clean_native_grid.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))

polys={str(t):[[(p.x,p.y) for p in l.polygon3d()] for l in lanes_near(nearest(t)['ego'])] for t in [1789074331.3013,1789074418.8675]}
(out/'clean_plot_polygons.json').write_text(json.dumps(polys))
