#include "hdmap/hdmap.hpp"
#include <lanelet2_core/geometry/Lanelet.h>
#include <lanelet2_traffic_rules/TrafficRulesFactory.h>
#include <boost/geometry/geometries/multi_polygon.hpp>
#include <boost/geometry/geometries/polygon.hpp>
using Poly=boost::geometry::model::polygon<lanelet::BasicPoint2d,true,false>;
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
int main(int argc,char** argv){
 auto map=hdmap::hdmap_init("/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin");auto rules=lanelet::traffic_rules::TrafficRulesFactory::create(lanelet::Locations::Germany,lanelet::Participants::Vehicle);
 std::ifstream input(argc>1?argv[1]:"/tmp/control_roadscan/input.txt");double t,x,y,z,yaw,speed;std::cout<<std::setprecision(15);
 while(input>>t>>x>>y>>z>>yaw>>speed){
  lanelet::BasicPolygon2d fp;double c=std::cos(yaw),s=std::sin(yaw);
  for(auto corner:std::vector<std::pair<double,double>>{{3.808,.943},{3.808,-.943},{-1.040,-.943},{-1.040,.943}})fp.emplace_back(x+c*corner.first-s*corner.second,y+s*corner.first+c*corner.second);
  boost::geometry::correct(fp);auto bbox=lanelet::geometry::boundingBox2d(fp);
  boost::geometry::model::multi_polygon<Poly> overlap;std::vector<lanelet::Id> ids;std::vector<bool> corners(fp.size(),false);bool rear=false,center=false;
  for(auto lane:map->laneletMap().laneletLayer.search(bbox)){
   if(!rules->canPass(lane))continue;double minz=1e9,maxz=-1e9;for(auto p:lane.polygon3d()){minz=std::min(minz,p.z());maxz=std::max(maxz,p.z());}if(z<minz-2.||z>maxz+2.)continue;auto poly=lane.polygon2d().basicPolygon();boost::geometry::correct(poly);std::vector<Poly> pieces;boost::geometry::intersection(poly,fp,pieces);
   if(pieces.empty())continue;ids.push_back(lane.id());center=center||boost::geometry::covered_by(lanelet::BasicPoint2d(x+1.384*c,y+1.384*s),poly);rear=rear||boost::geometry::covered_by(lanelet::BasicPoint2d(x,y),poly);for(std::size_t i=0;i<fp.size();++i)corners[i]=corners[i]||boost::geometry::covered_by(fp[i],poly);
   for(auto& piece:pieces){if(overlap.empty()){overlap.push_back(piece);continue;}boost::geometry::model::multi_polygon<Poly> joined;boost::geometry::union_(overlap,piece,joined);overlap=std::move(joined);}
  }
  double area=0;for(auto& p:overlap)area+=std::abs(boost::geometry::area(p));double full=std::abs(boost::geometry::area(fp));
  std::cout<<"{\"t\":"<<t<<",\"x\":"<<x<<",\"y\":"<<y<<",\"z\":"<<z<<",\"heading\":"<<yaw<<",\"speed\":"<<speed<<",\"body_area\":"<<full<<",\"road_overlap_area\":"<<area<<",\"outside_fraction\":"<<1-area/full<<",\"rear_on_road\":"<<(rear?"true":"false")<<",\"center_on_road\":"<<(center?"true":"false")<<",\"corners_on_road\":[";
  for(std::size_t i=0;i<corners.size();++i){if(i)std::cout<<",";std::cout<<(corners[i]?"true":"false");}std::cout<<"],\"lanes\":[";for(std::size_t i=0;i<ids.size();++i){if(i)std::cout<<",";std::cout<<ids[i];}std::cout<<"]}\n";
 }
}
