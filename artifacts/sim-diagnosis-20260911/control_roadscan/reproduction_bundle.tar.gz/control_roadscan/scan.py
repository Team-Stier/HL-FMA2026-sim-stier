import json,math,sys,subprocess,os
from pathlib import Path
src=Path(sys.argv[1]);tag=sys.argv[2];out=Path('/tmp/control_roadscan');state={};path=None;last=None;metas=[];rows=[]
for line in src.open():
 try:a=json.loads(line)
 except json.JSONDecodeError:continue
 state[a['topic']]=a['data']
 if a['topic']=='path':path=a
 if a['topic']!='ego':continue
 if len(sys.argv)>3 and a['t']<float(sys.argv[3]):continue
 e=a['data'];delta=math.hypot(e['x']-last['x'],e['y']-last['y']) if last else 999
 if last and delta<.1 and abs(e['heading']-last['heading'])<.015:continue
 last=e
 rows.append(' '.join(map(str,[a['t'],e['x'],e['y'],e['z'],e['heading'],e['speed']])))
 metas.append({'t':a['t'],'ego':e,'status':state.get('status'),'command':state.get('command'),'cap':state.get('cap'),'route':state.get('route'),'light':state.get('light'),'path_t':path['t'] if path else None,'path_n':len(path['data']['points']) if path else None,'path_age':(a['stamp']-path['stamp'])/1e9 if path else None,'path_capture_error_ms':path['data'].get('capture_error_ms') if path else None,'jump':delta>10})
(out/(tag+'_input.txt')).write_text('\n'.join(rows)+'\n');(out/(tag+'_meta.json')).write_text(json.dumps(metas))
with (out/(tag+'_coverage.jsonl')).open('w') as f: subprocess.run(['/tmp/control_roadscan/containment',str(out/(tag+'_input.txt'))],stdout=f,check=True)
coverage=[json.loads(x) for x in (out/(tag+'_coverage.jsonl')).open()];combined=[dict(m,coverage=c) for m,c in zip(metas,coverage)];(out/(tag+'_combined.jsonl')).write_text('\n'.join(json.dumps(x) for x in combined)+'\n')
bad=[x for x in combined if x['coverage']['outside_fraction']>.01 or not all(x['coverage']['corners_on_road']) or not x['coverage'].get('center_on_road',True)]
episodes=[]
for x in bad:
 if episodes and x['t']-episodes[-1][-1]['t']<1:episodes[-1].append(x)
 else:episodes.append([x])
summary={'source':str(src),'samples':len(combined),'bad_samples':len(bad),'episodes':[]}
for ep in episodes:
 if len(ep)<2:continue
 worst=max(ep,key=lambda x:x['coverage']['outside_fraction']);summary['episodes'].append({'start':ep[0],'worst':worst,'last':ep[-1],'samples':len(ep)})
(out/(tag+'_summary.json')).write_text(json.dumps(summary,indent=2));print(json.dumps({'samples':len(combined),'bad_samples':len(bad),'episodes':[{k:({'t':v['t'],'xy':[v['ego']['x'],v['ego']['y']],'outside':v['coverage']['outside_fraction'],'corners':v['coverage']['corners_on_road'],'center':v['coverage'].get('center_on_road'),'status':v['status'],'age':v['path_age'],'speed':v['ego']['speed']} if k in ('start','worst','last') else v) for k,v in ep.items()} for ep in summary['episodes']]},indent=2))
