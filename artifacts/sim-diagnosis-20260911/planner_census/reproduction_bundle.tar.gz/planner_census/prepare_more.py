from pathlib import Path
import json,gzip
src=Path('/tmp/sim_diagnosis_extended');out=Path('/tmp/planner_census');metas=[json.loads(f.read_text()) for f in (src/'snapshots').glob('*.json')]
rows=[]
for l in (src/'events.jsonl').read_text().splitlines():
 try:rows.append(json.loads(l))
 except json.JSONDecodeError:pass
paths={r['stamp']:r for r in rows if r['topic']=='path'}
cases=[('south_curve',1789073830.3975406,1789073882,[(1111.15,-1122.26),(1120.25,-1115.76),(1126.86,-1106.80)]),('west_downhill',1789073883.3593318,1789073914,[(536.41,-410.31),(547.91,-401.47),(565.14,-386.99)]),('north_red',1789074473.5527918,1789074504,[(1438.7323,1020.0327),(1438.957,1014.5746),(1439.2233,1007.9301),(1439.4219,1002.1347),(1439.6207,997.1386),(1439.926,991.8108),(1440.3961,983.9382)]),('north_green',1789074584.0489154,1789074622,[(1440.2395,984.2785),(1440.24,984.2668),(1440.3698,981.1523)])]
manifest=[]
for name,start,end,points in cases:
 pool=[m for m in metas if start<=m['t']<end];selected=[]
 for x,y in points:
  m=min(pool,key=lambda m:(m['ego']['x']-x)**2+(m['ego']['y']-y)**2)
  if m not in selected:selected.append(m)
 entries=[]
 for r in rows:
  if not start<=r['t']<end:continue
  if r['topic']=='ego':
   e=r['data'];entries.append((r['t'],f'E {r["stamp"]} '+' '.join(str(e[k]) for k in ['x','y','z','heading','speed'])))
  elif r['topic']=='route':entries.append((r['t'],'R '+str(len(r['data']))+' '+' '.join(map(str,r['data']))))
 for m in selected:
  stamp=str(m['stamp']);prefix=src/'snapshots'/stamp;binary=out/(stamp+'.dynamic.cdr');binary.write_bytes(gzip.decompress(Path(str(prefix)+'.dynamic.cdr.gz').read_bytes()));p=paths.get(m['stamp']);t=p['t'] if p else m['t'];entries.append((t,f'S {stamp} {prefix}.ego.cdr {binary}'));manifest.append(m|{'case':name,'published_path':p,'replay_t':t})
 last=max(t for t,line in entries if line.startswith('S '));entries=[(t,line) for t,line in entries if t<=last];entries.sort();(out/(name+'.timeline')).write_text('\n'.join(line for t,line in entries)+'\n')
 print(name,len(selected),'snapshots')
(out/'more_manifest.json').write_text(json.dumps(manifest,indent=2))
