from pathlib import Path
import json,gzip,bisect
source=Path('/tmp/sim_diagnosis_extended');out=Path('/tmp/planner_census');out.mkdir(exist_ok=True)
metas=[json.loads(f.read_text())|{'file':f} for f in (source/'snapshots').glob('*.json')];metas.sort(key=lambda d:d['t'])
# Bounded snapshots before lanelet pinning, at shrinking endpoints, and after a route-current transition.
requests=[(773.05,-90.62),(782.80,-89.76),(786.34,-89.19),(791.33,-88.24),(793.25,-87.75),(794.33,-87.46),(798.23,-85.69),(850.47,-27.35),(854.67,-14.02),(857.05,-5.7),(868.03,150.98),(877.43,164.53)]
selected=[]
for x,y in requests:
 choices=[d for d in metas if d['ego']['speed']>.5]
 m=min(choices,key=lambda d:(d['ego']['x']-x)**2+(d['ego']['y']-y)**2)
 if m not in selected:selected.append(m)
rows=[]
with (source/'events.jsonl').open() as f:
 for line in f:
  try:rows.append(json.loads(line))
  except json.JSONDecodeError:pass
paths={r['stamp']:r for r in rows if r['topic']=='path'}
actions=json.loads('[]')
try:actions=[json.loads(l) for l in (source/'actions.jsonl').read_text().splitlines()]
except Exception:pass
entries=[]
for r in rows:
 if r['topic']=='ego':
  e=r['data'];entries.append((r['t'],f'E {r["stamp"]} '+ ' '.join(str(e[k]) for k in ['x','y','z','heading','speed'])))
 elif r['topic']=='route':entries.append((r['t'],'R '+str(len(r['data']))+' '+' '.join(map(str,r['data']))))
manifest=[]
for m in selected:
 stamp=str(m['stamp']);prefix=source/'snapshots'/stamp;binary=out/(stamp+'.dynamic.cdr');binary.write_bytes(gzip.decompress(Path(str(prefix)+'.dynamic.cdr.gz').read_bytes()))
 p=paths.get(m['stamp']);entry_t=p['t'] if p else m['t'];entries.append((entry_t,f'S {stamp} {prefix}.ego.cdr {binary}'))
 manifest.append({**{k:v for k,v in m.items() if k!='file'},'replay_t':entry_t,'published_path':p})
last=max(t for t,line in entries if line.startswith('S '));entries=[(t,line) for t,line in entries if t<=last];entries.sort(key=lambda p:p[0]);(out/'timeline.txt').write_text('\n'.join(line for t,line in entries)+'\n');(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Selected',len(selected),'snapshots;',len(entries),'timeline events')
for m in manifest:print(m['stamp'],m['ego']['x'],m['ego']['y'],m['route'][:3],bool(m['published_path']))
