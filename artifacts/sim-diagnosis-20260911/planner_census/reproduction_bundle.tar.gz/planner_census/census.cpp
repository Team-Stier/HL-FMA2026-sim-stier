#define main production_main_unused
#include "instrumented_planner.cpp"
#undef main
#include <cstring>
#include <iostream>
#include <iomanip>
#include <map>
#include <iterator>

using namespace path_planner;

template<class Message> Message readCdr(const std::string& path) {
 std::ifstream input(path,std::ios::binary); if(!input)throw std::runtime_error("Missing CDR: "+path);
 std::vector<char> bytes{std::istreambuf_iterator<char>(input),std::istreambuf_iterator<char>()};
 rclcpp::SerializedMessage buffer(bytes.size()); auto& raw=buffer.get_rcl_serialized_message();
 std::memcpy(raw.buffer,bytes.data(),bytes.size());raw.buffer_length=bytes.size();
 Message message;rclcpp::Serialization<Message>{}.deserialize_message(&buffer,&message);return message;
}
template<class T> void array(const std::vector<T>& values) {std::cout<<"[";for(std::size_t i=0;i<values.size();++i){if(i)std::cout<<",";std::cout<<values[i];}std::cout<<"]";}
static void number(double x){if(std::isfinite(x))std::cout<<x;else std::cout<<"null";}
static void collisionJson(const CollisionResult& r){std::cout<<"{\"index\":"<<r.index<<",\"forbidden\":"<<(r.forbidden_lane?"true":"false")<<",\"cell\":"<<r.cell<<",\"lane\":"<<r.lane<<",\"bin\":"<<r.bin<<"}";}
struct Census {
 const hdmap::HdMap& map; const lanelet::routing::RoutingGraph& graph; const PlannerConfig& cfg;
 ReferenceBuilder refs; FrenetPlanner planner;
 Census(const hdmap::HdMap& m,const lanelet::routing::RoutingGraph& g,const PlannerConfig& c):map(m),graph(g),cfg(c),refs(m.laneletMap(),g),planner(m,g,c,nullptr,nullptr){}
 void run(const PlanningSnapshot& s,const std::string& label,const std::string& variant){
  if(!s.current_lane){std::cout<<"{\"kind\":\"skip\",\"snapshot\":\""<<label<<"\",\"reason\":\"no_current\"}\n";return;}
  auto set=refs.build(s.current_lane,s.global_path);
  if(variant!="baseline")for(auto& ref:set.references){
   const double target=project(ref,{s.ego.x,s.ego.y}).s+cfg.max_path_length;
   for(int step=0;ref.length()<target&&step<100;++step){
    const auto last=ref.diag_lanes.back();auto lane=map.laneletMap().laneletLayer.get(last);auto following=graph.following(lane,false);
    std::set<lanelet::Id> ids;for(const auto& next:following)ids.insert(next.id());
    const auto next_id=upcomingMatch(s.global_path,last,ids);
    if(!next_id||std::find(ref.diag_lanes.begin(),ref.diag_lanes.end(),next_id)!=ref.diag_lanes.end())break;
    appendCenterline(ref,map.laneletMap().laneletLayer.get(next_id));
    if(variant!="extended_reference_only")set.allowed_lanes.insert(next_id);
   }
  }
  std::cout<<"{\"kind\":\"snapshot\",\"snapshot\":\""<<label<<"\",\"variant\":\""<<variant<<"\",\"current\":"<<s.current_lane<<",\"intersection\":"<<(s.intersection?"true":"false")<<",\"ego_stamp\":"<<rclcpp::Time(s.ego.header.stamp).nanoseconds()<<",\"dynamic_stamp\":"<<rclcpp::Time(s.dynamic.header.stamp).nanoseconds()<<",\"ego\":["<<s.ego.x<<","<<s.ego.y<<","<<s.ego.z<<","<<s.ego.heading<<","<<s.ego.speed<<"],\"goals\":";array(s.goal_lanes);std::cout<<",\"route\":";array(s.global_path);std::cout<<",\"allowed\":";array(std::vector<lanelet::Id>(set.allowed_lanes.begin(),set.allowed_lanes.end()));std::cout<<"}\n";
  for(std::size_t i=0;i<set.references.size();++i){const auto& ref=set.references[i];auto initial=project(ref,{s.ego.x,s.ego.y});std::cout<<"{\"kind\":\"reference\",\"snapshot\":\""<<label<<"\",\"variant\":\""<<variant<<"\",\"index\":"<<i<<",\"lanes\":";array(ref.diag_lanes);std::cout<<",\"length\":"<<ref.length()<<",\"initial_s\":"<<initial.s<<",\"remaining\":"<<ref.length()-initial.s<<",\"initial_d\":"<<initial.d<<",\"heading_error\":"<<wrap(s.ego.heading-initial.yaw)<<"}\n";}
  if(s.goal_lanes.empty()){std::cout<<"{\"kind\":\"skip\",\"snapshot\":\""<<label<<"\",\"variant\":\""<<variant<<"\",\"reason\":\"empty_goals\"}\n";return;}
  auto candidates=planner.generate(s,set.references);auto goals=goalPoints(map.laneletMap(),s.goal_lanes);
  if(variant=="extended_reference_allowed_forward_goal"){
   const auto& ref=set.references.front();const auto goal=sample(ref,project(ref,{s.ego.x,s.ego.y}).s+cfg.max_path_length);goals={{goal.point,goal.yaw}};
   std::cout<<"{\"kind\":\"forward_goal\",\"snapshot\":\""<<label<<"\",\"point\":["<<goal.point.x()<<","<<goal.point.y()<<"],\"yaw\":"<<goal.yaw<<"}\n";
  }std::size_t winner=0;bool has_winner=false;std::map<std::string,int> counts;
  for(auto& p:candidates){
   Primitive collapsed;collapsed.x_m=p.x_m;collapsed.y_m=p.y_m;
   if(p.x_m.size()>2){collapsed.x_m={p.x_m.front()};collapsed.y_m={p.y_m.front()};for(std::size_t i=1;i+1<p.x_m.size();++i){double before=std::atan2(p.y_m[i]-p.y_m[i-1],p.x_m[i]-p.x_m[i-1]);double after=std::atan2(p.y_m[i+1]-p.y_m[i],p.x_m[i+1]-p.x_m[i]);if(std::abs(wrap(after-before))>1e-8){collapsed.x_m.push_back(p.x_m[i]);collapsed.y_m.push_back(p.y_m[i]);}}collapsed.x_m.push_back(p.x_m.back());collapsed.y_m.push_back(p.y_m.back());}
   const bool collapsed_ok=collapsed.x_m.size()>1&&kinematicallyFeasible(collapsed,s.ego.heading,cfg.wheelbase_m,cfg.maximum_curvature_per_m,cfg.maximum_steering_rad);
   const double original_length=pathLength(p);const std::size_t original_count=p.x_m.size();std::string stage="valid";CollisionResult first{},recheck{};bool trimmed=false;std::size_t empty_initial=0;
   if(!p.diag_kin_ok)stage=p.x_m.size()<2?"generation_too_few":"kinematic";
   else if(!planner.velocity_.plan(p,s))stage="velocity";
   else{
    empty_initial=p.diag_empty_cell_count;first=planner.validator_.firstCollision(p,s,set.allowed_lanes);
    if(first.forbidden_lane)stage="forbidden_lane";
    else if(first.index<p.x_m.size()){
     if(first.index<2)stage="collision_before_two_points";
     else{trimmed=true;FrenetPlanner::resize(p,first.index);
      if(!planner.velocity_.plan(p,s,true))stage="trim_velocity";
      else{recheck=planner.validator_.firstCollision(p,s,set.allowed_lanes);if(recheck.forbidden_lane)stage="trim_forbidden_lane";else if(recheck.index<p.x_m.size())stage="trim_collision";}
     }
    }
   }
   if(stage=="valid"){
    planner.costs_.evaluate(p,goals);if(!has_winner||p.cost<candidates[winner].cost){winner=p.diag_id;has_winner=true;}
   }
   ++counts[stage];std::cout<<"{\"kind\":\"candidate\",\"snapshot\":\""<<label<<"\",\"variant\":\""<<variant<<"\",\"id\":"<<p.diag_id<<",\"reference\":"<<p.diag_reference<<",\"horizon\":"<<p.diag_horizon<<",\"terminal_nominal_speed\":"<<p.diag_terminal_speed<<",\"nominal_end_time\":"<<p.diag_end_time<<",\"generation_stop\":\""<<p.diag_generation_stop<<"\",\"generated_length\":"<<original_length<<",\"generated_count\":"<<original_count<<",\"final_length\":"<<pathLength(p)<<",\"final_count\":"<<p.x_m.size()<<",\"stage\":\""<<stage<<"\",\"first_point_gap\":"<<(p.x_m.empty()?0:std::hypot(p.x_m.front()-s.ego.x,p.y_m.front()-s.ego.y))<<",\"max_curvature_until_reject\":"<<p.diag_curvature<<",\"kinematic_reject_index\":"<<p.diag_kin_index<<",\"velocity_error\":\""<<p.diag_velocity_error<<"\",\"required_initial_speed\":"<<p.diag_start_speed_required<<",\"initial_empty_cell_points\":"<<empty_initial<<",\"trimmed\":"<<(trimmed?"true":"false")<<",\"collision\":";collisionJson(first);std::cout<<",\"recheck\":";collisionJson(recheck);
   std::cout<<",\"collinear_collapsed_kinematic_ok\":"<<(collapsed_ok?"true":"false")<<",\"collinear_collapsed_curvature\":"<<collapsed.diag_curvature<<",\"collinear_collapsed_count\":"<<collapsed.x_m.size();
   if(!p.x_m.empty())std::cout<<",\"first_point\":["<<p.x_m.front()<<","<<p.y_m.front()<<"]";
   if(stage=="valid"){std::cout<<",\"cost\":";number(p.cost);std::cout<<",\"cost_terms\":{\"lateral\":";number(p.diag_lateral_cost);std::cout<<",\"time\":";number(p.diag_time_cost);std::cout<<",\"goal\":";number(p.diag_goal_cost);std::cout<<",\"progress\":";number(p.diag_progress_cost);std::cout<<",\"alignment\":";number(p.diag_alignment_cost);std::cout<<",\"centerline\":";number(p.diag_centerline_cost);std::cout<<"}";}
   std::cout<<"}\n";
  }
  std::cout<<"{\"kind\":\"summary\",\"snapshot\":\""<<label<<"\",\"variant\":\""<<variant<<"\",\"winner\":"<<(has_winner?static_cast<int>(winner):-1)<<",\"counts\":{";bool first=true;for(const auto& [key,value]:counts){if(!first)std::cout<<",";first=false;std::cout<<"\""<<key<<"\":"<<value;}std::cout<<"}";
  if(has_winner){const auto& p=candidates[winner];std::cout<<",\"winner_length\":"<<pathLength(p)<<",\"winner_cost\":";number(p.cost);std::cout<<",\"winner_xy\":[";for(std::size_t i=0;i<p.x_m.size();++i){if(i)std::cout<<",";std::cout<<"["<<p.x_m[i]<<","<<p.y_m[i]<<"]";}std::cout<<"]";}
  std::cout<<"}\n";
 }
};
int main(int argc,char** argv){
 if(argc!=2){std::cerr<<"usage: census timeline.txt\n";return 2;}std::cout<<std::setprecision(15);
 PlannerConfig cfg{10,50,1,1,10,1,1,10,2,.174532925199,1,{2,2.5,3,3.5,4},.5,.5,1,5.45,10.37,2.95,.169492,26.565*std::acos(-1.)/180.,3.808,1.040,.943,.943,1.507};
 auto map=hdmap::hdmap_init("/home/stier/HL-FMA2026-sim-stier/map/hdmap.bin");auto rules=lanelet::traffic_rules::TrafficRulesFactory::create(lanelet::Locations::Germany,lanelet::Participants::Vehicle);auto graph=lanelet::routing::RoutingGraph::build(map->laneletMap(),*rules);IntersectionMonitor monitor(map->laneletMap(),cfg);RouteUpdater updater(map->laneletMap(),*graph,cfg,"/home/stier/HL-FMA2026-sim-stier/src/path_planner/checkpoint/checkpoints.csv",nullptr);PlanningSnapshot state;Census census(*map,*graph,cfg);
 std::ifstream input(argv[1]);std::string line;std::size_t snapshot_count=0;
 while(std::getline(input,line)){std::istringstream row(line);char type;row>>type;
  if(type=='E'){std::int64_t stamp;row>>stamp>>state.ego.x>>state.ego.y>>state.ego.z>>state.ego.heading>>state.ego.speed;state.ego.header.stamp=rclcpp::Time(stamp);}
  else if(type=='R'){std::size_t n;row>>n;std::vector<lanelet::Id> ids(n);for(auto& id:ids)row>>id;const auto [current,intersection]=monitor.inspect(state.ego);if(!(intersection&&!state.global_path.empty()))state.goal_lanes=ids.size()>1?updater.updateGoals(state,current,intersection,ids):std::vector<lanelet::Id>{};state.current_lane=current.id();state.intersection=intersection;state.global_path=ids;}
  else if(type=='S'){std::string label,ego_path,dynamic_path;row>>label>>ego_path>>dynamic_path;auto s=state;s.ego=readCdr<EgoStatus>(ego_path);s.dynamic=readCdr<DynamicStatus>(dynamic_path);for(const auto& variant:{"baseline","extended_reference_only","extended_reference_and_allowed","extended_reference_allowed_forward_goal"})census.run(s,label,variant);++snapshot_count;std::cerr<<"snapshot "<<snapshot_count<<" "<<label<<"\n";}
 }
}
