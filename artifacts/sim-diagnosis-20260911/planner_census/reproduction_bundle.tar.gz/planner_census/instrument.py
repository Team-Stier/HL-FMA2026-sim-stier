from pathlib import Path
src=Path('/home/stier/HL-FMA2026-sim-stier/src/path_planner/src/path_planner_node.cpp').read_text()
def replace(old,new,count=1):
 global src
 assert src.count(old)>=count,old
 src=src.replace(old,new,count)
src=src.replace('private:', 'public:')
replace('struct Primitive {','''struct Primitive {
    std::size_t diag_id{}, diag_reference{}, diag_kin_index{};
    double diag_horizon{}, diag_terminal_speed{}, diag_end_time{}, diag_curvature{}, diag_start_speed_required{};
    double diag_goal_cost{}, diag_progress_cost{}, diag_alignment_cost{}, diag_centerline_cost{}, diag_time_cost{}, diag_lateral_cost{};
    std::size_t diag_empty_cell_count{};
    std::string diag_generation_stop, diag_velocity_error;
    bool diag_kin_ok{};
''')
replace('struct Reference {','struct Reference {\n    std::vector<lanelet::Id> diag_lanes;')
replace('static void appendCenterline(Reference& reference, const lanelet::ConstLanelet& lane) {','static void appendCenterline(Reference& reference, const lanelet::ConstLanelet& lane) {\n    reference.diag_lanes.push_back(lane.id());')
replace('static bool kinematicallyFeasible(const Primitive& primitive','static bool kinematicallyFeasible(Primitive& primitive')
replace('        if (length <= 1e-6) return false;','        if (length <= 1e-6) { primitive.diag_kin_index=index; return false; }')
replace('        if (curvature > maximum_curvature ||\n            std::atan(wheelbase * curvature) > maximum_steering) return false;','''        primitive.diag_curvature = std::max(primitive.diag_curvature, curvature);
        if (curvature > maximum_curvature ||
            std::atan(wheelbase * curvature) > maximum_steering) { primitive.diag_kin_index=index; return false; }''')
replace('        if (count < 2) return false;','        primitive.diag_empty_cell_count=0; primitive.diag_velocity_error.clear();\n        if (count < 2) { primitive.diag_velocity_error="too_few_points"; return false; }')
replace('            for (const auto cell : cells) {','            if (cells.empty()) ++primitive.diag_empty_cell_count;\n            for (const auto cell : cells) {')
replace('        if (primitive.speed_mps.front() + 1e-6 < snapshot.ego.speed) return false;','''        if (primitive.speed_mps.front() + 1e-6 < snapshot.ego.speed) {
            primitive.diag_start_speed_required=primitive.speed_mps.front();
            primitive.diag_velocity_error="initial_speed_exceeds_braking_feasibility"; return false;
        }''')
replace('            if (!std::isfinite(average) || average <= 0.) return false;','            if (!std::isfinite(average) || average <= 0.) { primitive.diag_velocity_error="invalid_average_speed"; return false; }')
replace('struct CollisionResult {','struct CollisionResult {')
replace('    bool forbidden_lane{};\n};','    bool forbidden_lane{};\n    std::int64_t cell{-1}, lane{-1}, bin{-1};\n};')
replace('if (cell >= map_.cells().size()) return {index, true};','if (cell >= map_.cells().size()) return {index, true, cell, -1, static_cast<std::int64_t>(bin)};')
replace('                    return {index, true};','                    return {index, true, cell, parent_id, static_cast<std::int64_t>(bin)};')
replace('snapshot.dynamic.occupancy_probability[offset] > 0.F) return {index, false};','snapshot.dynamic.occupancy_probability[offset] > 0.F) return {index, false, cell, parent_id, static_cast<std::int64_t>(bin)};')
replace('        primitive.cost = config_.lateral_cost_weight * primitive.lateral_cost +','''        primitive.diag_lateral_cost=config_.lateral_cost_weight * primitive.lateral_cost;
        primitive.diag_time_cost=config_.time_cost_weight * primitive.eta_s.back();
        primitive.diag_goal_cost=config_.goal_cost_weight * goal_distance;
        primitive.diag_progress_cost=config_.progress_cost_weight * progress * progress;
        primitive.diag_alignment_cost=config_.alignment_cost_weight * std::pow(wrap(primitive.yaw_rad.back()-goal_yaw),2);
        primitive.diag_centerline_cost=config_.centerline_deviation_cost_weight * centerlineDeviationCost(primitive);
        primitive.cost = config_.lateral_cost_weight * primitive.lateral_cost +''')
replace('        for (const auto& reference : references) {','        std::size_t diag_reference=0;\n        for (const auto& reference : references) {\n            const auto this_reference=diag_reference++;')
replace('                    Primitive primitive;','''                    Primitive primitive;
                    primitive.diag_id=result.size(); primitive.diag_reference=this_reference;
                    primitive.diag_horizon=duration; primitive.diag_terminal_speed=terminal_speeds[speed_index];''')
replace('                        if (station < 0.) break;','                        if (station < 0.) { primitive.diag_generation_stop="negative_station"; break; }')
replace('''                        if (reference_end || pathLength(primitive) >= config_.max_path_length ||
                            nominal_time >= duration) break;''','''                        if (reference_end || pathLength(primitive) >= config_.max_path_length || nominal_time >= duration) {
                            primitive.diag_generation_stop=reference_end?"reference_end":pathLength(primitive)>=config_.max_path_length?"max_length_after_time_step":"horizon";
                            primitive.diag_end_time=nominal_time; break;
                        }''')
replace('                    if (primitive.x_m.size() < 2) continue;','                    if (primitive.x_m.size() < 2) { primitive.diag_generation_stop="too_few_points"; result.push_back(std::move(primitive)); continue; }')
replace('''                    if (!kinematicallyFeasible(primitive, snapshot.ego.heading,
                            config_.wheelbase_m, config_.maximum_curvature_per_m,
                            config_.maximum_steering_rad)) continue;''','''                    primitive.diag_kin_ok=kinematicallyFeasible(primitive, snapshot.ego.heading,
                            config_.wheelbase_m, config_.maximum_curvature_per_m,
                            config_.maximum_steering_rad);''')
Path('/tmp/planner_census/instrumented_planner.cpp').write_text(src)
print('Wrote instrumented source snapshot; production source unchanged')
