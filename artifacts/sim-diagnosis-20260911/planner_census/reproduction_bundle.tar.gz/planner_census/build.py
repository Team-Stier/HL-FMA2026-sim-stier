from pathlib import Path
import shlex,subprocess
p=Path('/tmp/planner_census'); root=Path('/home/stier/HL-FMA2026-sim-stier')
flags={line.split(' = ')[0]: shlex.split(line.split(' = ',1)[1]) for line in (root/'build/path_planner/CMakeFiles/cost_check.dir/flags.make').read_text().splitlines() if ' = ' in line};link=shlex.split((root/'build/path_planner/CMakeFiles/cost_check.dir/link.txt').read_text());cmd=['/usr/bin/c++','-O1','-std=c++17',*flags['CXX_DEFINES'],*flags['CXX_INCLUDES'],str(p/'census.cpp'),'-o',str(p/'census'),*link[link.index('-o')+2:]]
result=subprocess.run(cmd,stdout=(p/'compile.log').open('w'),stderr=subprocess.STDOUT)
print('compile exit',result.returncode)
