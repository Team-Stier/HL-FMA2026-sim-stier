from pathlib import Path
import json,math,collections
p=Path('/tmp/planner_census');files=['results.jsonl','south_curve.results.jsonl','west_downhill.results.jsonl','live_goal.results.jsonl','north_red.results.jsonl','north_green.results.jsonl'];rows=[json.loads(l) for f in files for l in (p/f).read_text().splitlines()]
manifest=[m for f in ['manifest.json','more_manifest.json','live_goal_manifest.json'] for m in json.loads((p/f).read_text())];trees={}
for line in Path('/tmp/sim_diagnosis_extended/trees.jsonl').read_text().splitlines():
 try:r=json.loads(line);trees[r['stamp']]=r
 except json.JSONDecodeError:pass
cases=[]
for m in manifest:
 stamp=str(m['stamp']);group=[r for r in rows if r['snapshot']==stamp];summary={'stamp':stamp,'t':m['t'],'ego':m['ego'],'case':m.get('case','short_successor'), 'dynamic_source_stamp':m.get('dynamic_source_stamp',m['stamp']),'variants':{}}
 for variant in ['baseline','extended_reference_only','extended_reference_and_allowed','extended_reference_allowed_forward_goal']:
  selected=[r for r in group if r.get('variant')==variant];state=next(r for r in selected if r['kind']=='snapshot');total=next(r for r in selected if r['kind']=='summary');cs=[r for r in selected if r['kind']=='candidate'];valid=[r for r in cs if r['stage']=='valid'];winner=next((r for r in valid if r['id']==total['winner']),None);longest=max(valid,key=lambda r:r['final_length']) if valid else None
  summary['variants'][variant]={'current':state['current'],'goals':state['goals'],'references':[r for r in selected if r['kind']=='reference'],'counts':total['counts'],'winner':winner,'longest_valid':longest,'kinematic_resampling_sensitive_count':sum(r['stage']=='kinematic' and r['collinear_collapsed_kinematic_ok'] for r in cs)}
 baseline=next(r for r in group if r['kind']=='summary' and r['variant']=='baseline');path=m['published_path'];validation={'published_path':bool(path),'replayed_winner':baseline['winner']}
 if path:
  e=m['ego'];c,s=math.cos(e['heading']),math.sin(e['heading']);actual=[(e['x']+c*q[0]-s*q[1],e['y']+s*q[0]+c*q[1]) for q in path['data']['points']];expected=baseline.get('winner_xy',[]);validation['actual_point_count']=len(actual);validation['replayed_point_count']=len(expected);validation['max_point_error_m']=max(math.dist(a,b) for a,b in zip(actual,expected)) if len(actual)==len(expected) else None
 tree=trees.get(m['stamp']);valid=[r for r in group if r.get('variant')=='baseline' and r['kind']=='candidate' and r['stage']=='valid']
 if tree:
  validation['live_valid_count']=len(tree['candidates']);validation['replayed_valid_count']=len(valid);validation['live_selected_index']=tree['selected'];validation['replayed_selected_index']=[r['id'] for r in valid].index(baseline['winner']) if valid else -1;validation['max_valid_length_error_m']=max(abs(r['final_length']-c['length']) for r,c in zip(valid,tree['candidates'])) if len(valid)==len(tree['candidates']) else None
 summary['validation']=validation;cases.append(summary)
counts=collections.Counter()
for c in cases:counts.update(c['variants']['baseline']['counts'])
report={'snapshot_count':len(cases),'published_paths':sum(c['validation']['published_path'] for c in cases),'no_path_cases':sum(not c['validation']['published_path'] for c in cases),'pointwise_max_error_m':max(c['validation'].get('max_point_error_m',0) or 0 for c in cases),'live_tree_count':sum('live_valid_count' in c['validation'] for c in cases),'live_tree_max_candidate_length_error_m':max(c['validation'].get('max_valid_length_error_m',0) or 0 for c in cases),'baseline_stage_counts':dict(counts),'cases':cases}
(p/'summary.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
