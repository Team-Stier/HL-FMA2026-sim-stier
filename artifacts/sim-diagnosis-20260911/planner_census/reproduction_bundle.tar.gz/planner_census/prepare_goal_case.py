from pathlib import Path
import json,gzip
from rclpy.serialization import serialize_message
from interfaces.msg import EgoStatus
src=Path('/tmp/sim_diagnosis_extended');out=Path('/tmp/planner_census');rows=[]
for l in (src/'events.jsonl').read_text().splitlines():
 try:rows.append(json.loads(l))
 except json.JSONDecodeError:pass
paths={r['stamp']:r for r in rows if r['topic']=='path'};egos={r['stamp']:r for r in rows if r['topic']=='ego'}
requests=[1789073777459150537,1789073777698673150,1789073778099122085];entries=[];manifest=[]
for r in rows:
 if not 1789073724.0535004<=r['t']<1789073779:continue
 if r['topic']=='ego':
  e=r['data'];entries.append((r['t'],f'E {r["stamp"]} '+' '.join(str(e[k]) for k in ['x','y','z','heading','speed'])))
 elif r['topic']=='route':entries.append((r['t'],'R '+str(len(r['data']))+' '+' '.join(map(str,r['data']))))
for stamp in requests:
 label=str(stamp);prefix=src/'snapshots'/label
 if Path(str(prefix)+'.json').exists():
  meta=json.loads(Path(str(prefix)+'.json').read_text());ego_file=Path(str(prefix)+'.ego.cdr');dynamic_source=stamp
 else:
  recorded=egos[stamp];ego=EgoStatus();ego.header.stamp.sec=stamp//10**9;ego.header.stamp.nanosec=stamp%10**9;ego.header.frame_id='map'
  for k,v in recorded['data'].items():setattr(ego,k,float(v))
  ego_file=out/(label+'.ego.cdr');ego_file.write_bytes(serialize_message(ego));meta={'stamp':stamp,'t':recorded['t'],'ego':recorded['data'],'reason':'exact_ego_with_preceding_dynamic'};dynamic_source=1789073777459150537
 path=paths[stamp];dynamic_file=out/(str(dynamic_source)+'.dynamic.cdr');dynamic_file.write_bytes(gzip.decompress((src/'snapshots'/f'{dynamic_source}.dynamic.cdr.gz').read_bytes()));entries.append((path['t'],f'S {label} {ego_file} {dynamic_file}'));manifest.append(meta|{'case':'live_long_valid_loses','published_path':path,'dynamic_source_stamp':dynamic_source})
entries.sort();(out/'live_goal.timeline').write_text('\n'.join(line for t,line in entries)+'\n');(out/'live_goal_manifest.json').write_text(json.dumps(manifest,indent=2));print('Prepared',len(manifest),'live goal-cost cases')
